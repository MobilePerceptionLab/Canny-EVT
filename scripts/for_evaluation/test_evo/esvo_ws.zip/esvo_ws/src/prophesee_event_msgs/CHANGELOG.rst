^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package prophesee_event_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.2 (2019-10-09)
------------------

0.0.1 (2019-10-09)
------------------
* Merge pull request #4 from uzh-rpg/master
  Event messages harmonization with existing event-based sensors within the ROS ecosystem
* prophesee_event_msgs: correct comment in Event ros message.
* Merge branch 'master' of github.com:uzh-rpg/prophesee_ros_wrapper
* prophesee_event_msgs: event buffer with header. events with ros::Time as timestamp
  prophesee_ros_driver: adapt driver and visualizer to the new event messages.
* Initial version
* Contributors: Javier Hidalgo-Carrió, Natalia Lyubova, meliortony
