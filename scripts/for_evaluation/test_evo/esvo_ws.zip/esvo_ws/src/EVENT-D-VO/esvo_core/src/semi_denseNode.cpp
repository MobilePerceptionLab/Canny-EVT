#include <esvo_core/semi_dense.h>

int main(int argc, char **argv) {
  ros::init(argc, argv, "semi_dense");
  ros::NodeHandle nh;
  ros::NodeHandle nh_private("~");

  esvo_core::semi_dense mapper(nh, nh_private);
  ros::spin();
  return 0;
}