#include <esvo_core/semi_dense.h>
//#include <esvo_core/DVS_MappingStereoConfig.h>
#include <esvo_core/tools/params_helper.h>

#include <minkindr_conversions/kindr_tf.h>
#include <esvo_core/tools/utils.h>

#include <geometry_msgs/TransformStamped.h>

#include <opencv2/imgproc.hpp>
#include <cv_bridge/cv_bridge.h>

#include <pcl/point_types.h>
#include <pcl/filters/voxel_grid.h>

#include <thread>
#include <iterator>
#include <memory>
#include <algorithm>
#include <utility>

#include <Eigen/Dense>
#include <opencv2/core/eigen.hpp>
#include <opencv2/opencv.hpp>

#include <pcl/common/transforms.h>
#include <pcl/console/parse.h>
#include <pcl/console/time.h>
#include <pcl/point_types.h>
#include <pcl/io/pcd_io.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/ransac.h>
#include <pcl/sample_consensus/sac_model_registration.h>


#include <boost/make_shared.hpp>
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include <pcl/point_representation.h>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/filters/filter.h>
#include <pcl/features/normal_3d.h>
#include <pcl/registration/icp.h>
#include <pcl/registration/icp_nl.h>
#include <pcl/registration/transforms.h>

#include <pcl/search/impl/search.hpp>
 
#ifndef PCL_NO_PRECOMPILE
#include <pcl/impl/instantiate.hpp>
#include <pcl/point_types.h>
PCL_INSTANTIATE(Search, PCL_POINT_TYPES);
#endif // PCL_NO_PRECOMPILE


//#define ESVO_CORE_SEMIDENSE_DEBUG
//#define ESVO_CORE_SEMIDENSE_LOG

namespace esvo_core
{
  semi_dense::semi_dense(
      const ros::NodeHandle &nh,
      const ros::NodeHandle &nh_private)
      : nh_(nh),
        pnh_(nh_private),
        TS_left_sub_(nh_, "time_surface_left", 10),
        //TS_right_sub_(nh_, "time_surface_right", 10),
        depth_map_sub_(nh_, "depth_map", 10),
        image_sub_(nh_, "image", 10),
        DI_sync_(ApproximateSyncPolicy(10), depth_map_sub_, image_sub_, TS_left_sub_),
        it_(nh),
        init_t_(0),
        //calibInfoDir_(tools::param(pnh_, "calibInfoDir", std::string(""))),
        //camSysPtr_(new CameraSystem(calibInfoDir_, false)),
        pc_world_(new PointCloud()),
        pc_local_(new PointCloud()),
        pc_global_(new PointCloud()),
        pc_temp_(new PointCloud()),
        pc_ref_(new PointCloud())
  //pc_(new PointCloud()),
  //pc_near_(new PointCloud()),
  //pc_global_(new PointCloud()),
  //depthFramePtr_(new DepthFrame(camSysPtr_->cam_left_ptr_->height_, camSysPtr_->cam_left_ptr_->width_))
  {
    // frame id
    //ROS_INFO("0");
    dvs_frame_id_ = tools::param(pnh_, "dvs_frame_id", std::string("dvs"));
    world_frame_id_ = tools::param(pnh_, "world_frame_id", std::string("world"));
    depth_frame_id_ = tools::param(pnh_, "depth_frame_id", std::string("depth"));
    pc_world_->header.frame_id = world_frame_id_;
    pc_local_->header.frame_id = world_frame_id_;
    pc_global_->header.frame_id = world_frame_id_;
    pc_temp_->header.frame_id = world_frame_id_;
    pc_ref_->header.frame_id = world_frame_id_;
    //pc_near_->header.frame_id = world_frame_id_;
    //pc_global_->header.frame_id = world_frame_id_;
    POSE_LENGTH_ = tools::param(pnh_, "POSE_LENGTH", 500);
    TIME_DEPTH_LENGTH_ = tools::param(pnh_, "TIME_DEPTH_LENGTH", 10);
    makeSD_rate_hz_ = tools::param(pnh_, "makeSD_rate_hz", 10);
    /*
  camera_matrix:
  rows: 3
  cols: 3
  data: [226.38018519795807, 0.0, 173.6470807871759, 0.0, 226.15002947047415, 133.73271487507847, 0, 0, 1]
  distortion_coefficients:
  rows: 1
  cols: 4
  data: [-0.048031442223833355, 0.011330957517194437, -0.055378166304281135, 0.021500973881459395]
rectification_matrix:
  rows: 3
  cols: 3
  data: [0.999877311526236, 0.015019439766575743, -0.004447282784398257,
         -0.014996983873604017, 0.9998748347535599, 0.005040367172759556,
         0.004522429630305261, -0.004973052949604937, 0.9999774079320989]
  projection_matrix:
  rows: 3
  cols: 4
  data: [199.6530123165822, 0.0, 177.43276376280926, 0.0,
         0.0, 199.6530123165822, 126.81215684365904, 0.0,
         0.0, 0.0, 1.0, 0.0]
  */
    distortion_coefficients_ = cv::Mat(1, 4, CV_64F);
    distortion_coefficients_.at<double>(0, 0) = -0.048031442223833355;
    distortion_coefficients_.at<double>(0, 1) = 0.011330957517194437;
    distortion_coefficients_.at<double>(0, 2) = -0.055378166304281135;
    distortion_coefficients_.at<double>(0, 3) = 0.021500973881459395;

    camera_matrix_ = cv::Mat(3, 3, CV_64F);
    camera_matrix_.at<double>(0, 0) = 226.38018519795807;
    camera_matrix_.at<double>(0, 1) = 0.0;
    camera_matrix_.at<double>(0, 2) = 173.6470807871759;
    camera_matrix_.at<double>(1, 0) = 0.0;
    camera_matrix_.at<double>(1, 1) = 226.15002947047415;
    camera_matrix_.at<double>(1, 2) = 133.73271487507847;
    camera_matrix_.at<double>(2, 0) = 0;
    camera_matrix_.at<double>(2, 1) = 0;
    camera_matrix_.at<double>(2, 2) = 1;

    rectification_matrix_ = cv::Mat(3, 3, CV_64F);
    rectification_matrix_.at<double>(0, 0) = 0.999877311526236;
    rectification_matrix_.at<double>(0, 1) = 0.015019439766575743;
    rectification_matrix_.at<double>(0, 2) = -0.004447282784398257;
    rectification_matrix_.at<double>(1, 0) = -0.014996983873604017;
    rectification_matrix_.at<double>(1, 1) = 0.9998748347535599;
    rectification_matrix_.at<double>(1, 2) = 0.005040367172759556;
    rectification_matrix_.at<double>(2, 0) = 0.004522429630305261;
    rectification_matrix_.at<double>(2, 1) = -0.004973052949604937;
    rectification_matrix_.at<double>(2, 2) = 0.9999774079320989;

    K_new_ = cv::Mat(3, 3, CV_64F);
    K_new_.at<double>(0, 0) = 199.6530123165822;
    K_new_.at<double>(0, 1) = 0.0;
    K_new_.at<double>(0, 2) = 177.43276376280926;
    K_new_.at<double>(1, 0) = 0.0;
    K_new_.at<double>(1, 1) = 199.6530123165822;
    K_new_.at<double>(1, 2) = 126.81215684365904;
    K_new_.at<double>(2, 0) = 0.0;
    K_new_.at<double>(2, 1) = 0.0;
    K_new_.at<double>(2, 2) = 1.0;

    /*
  // mapping parameters /
  // range and visualization threshold
  invDepth_min_range_   = tools::param(pnh_, "invDepth_min_range", 0.16);
  invDepth_max_range_   = tools::param(pnh_, "invDepth_max_range", 2.0);
  patch_area_           = tools::param(pnh_, "patch_size_X", 25) *  tools::param(pnh_, "patch_size_Y", 25);
  residual_vis_threshold_ = tools::param(pnh_, "residual_vis_threshold", 15);
  cost_vis_threshold_   = pow(residual_vis_threshold_,2) * patch_area_;
  stdVar_vis_threshold_ = tools::param(pnh_, "stdVar_vis_threshold", 0.005);
  age_max_range_        = tools::param(pnh_, "age_max_range", 5);
  age_vis_threshold_    = tools::param(pnh_, "age_vis_threshold", 0);
  fusion_radius_        = tools::param(pnh_, "fusion_radius", 0);
  maxNumFusionFrames_   = tools::param(pnh_, "maxNumFusionFrames", 10);
  FusionStrategy_      = tools::param(pnh_, "FUSION_STRATEGY", std::string("CONST_FRAMES"));
  maxNumFusionPoints_  = tools::param(pnh_, "maxNumFusionPoints", 2000);
  INIT_SGM_DP_NUM_Threshold_ = tools::param(pnh_, "INIT_SGM_DP_NUM_THRESHOLD", 500);
  // options
  bDenoising_          = tools::param(pnh_, "Denoising", false);
  bRegularization_     = tools::param(pnh_, "Regularization", false);
  resetButton_         = tools::param(pnh_, "ResetButton", false);
  // visualization parameters
  bVisualizeGlobalPC_ = tools::param(pnh_, "bVisualizeGlobalPC", false);
  visualizeGPC_interval_ = tools::param(pnh_, "visualizeGPC_interval", 3);
  visualize_range_ = tools::param(pnh_, "visualize_range", 2.5);
  numAddedPC_threshold_ = tools::param(pnh_, "NumGPC_added_oper_refresh", 1000);
  // module parameters
  PROCESS_EVENT_NUM_   = tools::param(pnh_, "PROCESS_EVENT_NUM", 500);
  TS_HISTORY_LENGTH_  = tools::param(pnh_, "TS_HISTORY_LENGTH", 100);
  mapping_rate_hz_     = tools::param(pnh_, "mapping_rate_hz", 20);
  // Event Block Matching (BM) parameters
  BM_half_slice_thickness_ = tools::param(pnh_, "BM_half_slice_thickness", 0.001);
  BM_patch_size_X_ = tools::param(pnh_, "patch_size_X", 25);
  BM_patch_size_Y_ = tools::param(pnh_, "patch_size_Y", 25);
  BM_min_disparity_ = tools::param(pnh_, "BM_min_disparity", 3);
  BM_max_disparity_ = tools::param(pnh_, "BM_max_disparity", 40);
  BM_step_          = tools::param(pnh_, "BM_step", 1);
  BM_ZNCC_Threshold_= tools::param(pnh_, "BM_ZNCC_Threshold", 0.1);
  BM_bUpDownConfiguration_ = tools::param(pnh_, "BM_bUpDownConfiguration", false);
  */
    ESVO_System_Status_ = "INITIALIZATION";
    nh_.setParam("/ESVO_SYSTEM_STATUS", ESVO_System_Status_);

    // callback functions
    stampedPose_sub_ = nh_.subscribe("stamped_pose", 0, &semi_dense::stampedPoseCallback, this);
    DI_sync_.registerCallback(boost::bind(&semi_dense::semidenseCallback, this, _1, _2, _3));
    // TF
    tf_ = std::make_shared<tf::Transformer>(true, ros::Duration(100.0));
    // result publishers
    //invDepthMap_pub_ = it_.advertise("Inverse_Depth_Map", 1);
    //stdVarMap_pub_ = it_.advertise("Standard_Variance_Map", 1);
    //ageMap_pub_ = it_.advertise("Age_Map", 1);
    //costMap_pub_ = it_.advertise("cost_map", 1);
    pc_pub_ = nh_.advertise<PointCloud>("/semi_dense/pointcloud_local", 1); //why not sensor_msgs::PointCloud2 class
    pose_pub_ = nh_.advertise<geometry_msgs::PoseStamped>("/semi_dense/pose_pub", 1);
    semi_dense_pub_ = nh_.advertise<sensor_msgs::Image>("/semi_dense/semi_dense_image", 1);
    canny_pub_ = nh_.advertise<sensor_msgs::Image>("/semi_dense/canny_image", 1);
    mask_pub_ = nh_.advertise<sensor_msgs::Image>("/semi_dense/mask_image", 1);
    //if(bVisualizeGlobalPC_)
    //{
    //  gpc_pub_ = nh_.advertise<PointCloud>("/esvo_mapping/pointcloud_global", 1);
    //  pc_global_->reserve(500000);
    //  t_last_pub_pc_ = 0.0;
    //}
    // multi-thread management
    mapping_thread_future_ = mapping_thread_promise_.get_future();
    reset_future_ = reset_promise_.get_future();

    // make semidense detached thread
    std::thread MakeSDThread(&semi_dense::MakeSDLoop, this,
                             std::move(mapping_thread_promise_), std::move(reset_future_));
    MakeSDThread.detach();

    // Dynamic reconfigure
    //dynamic_reconfigure_callback_ = boost::bind(&esvo_Mapping::onlineParameterChangeCallback, this, _1, _2);
    //server_.reset(new dynamic_reconfigure::Server<DVS_MappingStereoConfig>(nh_private));
    //server_->setCallback(dynamic_reconfigure_callback_);
  }

  semi_dense::~semi_dense()
  {
    pc_pub_.shutdown();
    //invDepthMap_pub_.shutdown();
    //stdVarMap_pub_.shutdown();
    //ageMap_pub_.shutdown();
    //costMap_pub_.shutdown();
  }

  bool semi_dense::MakeSDLoop(
      std::promise<void> prom_mapping,
      std::future<void> future_reset)
  {
    ros::Rate r(makeSD_rate_hz_);
    reff_.t_ = init_t_;

    while (ros::ok())
    {
      //ROS_INFO("while loop");
      // reset mapping rate
      if (changed_frame_rate_)
      {
        r = ros::Rate(makeSD_rate_hz_);
        changed_frame_rate_ = false;
      }

      // check system status
      nh_.getParam("/ESVO_SYSTEM_STATUS", ESVO_System_Status_);
      //    LOG(INFO) << "SYSTEM STATUS (MappingLoop): " << ESVO_System_Status_;
      if (ESVO_System_Status_ == "TERMINATE")
      {
        LOG(INFO) << "The MakeSD node is terminated manually...";
        break;
      }

      if (depth_mapPtr_.size() < 1)
      {
        r.sleep();
        continue;
      }

      // Make SD map
      {
        //std::lock_guard<std::mutex> lock(data_mutex_);

        if (reff_.t_.toSec() < depth_mapPtr_.rbegin()->first.toSec()) //new reference map arrived
        {
          //calculate the pose of depth map
          {
            std::lock_guard<std::mutex> lock(data_mutex_);
            curr_.t_ = depth_mapPtr_.rbegin()->first;
            curr_.cur_depth_ = depth_mapPtr_.rbegin()->second;
            curr_.cur_image_ = image_mapPtr_.rbegin()->second;
            curr_.cur_TS_ = TS_mapPtr_.rbegin()->second;
          }

          nh_.getParam("/ESVO_SYSTEM_STATUS", ESVO_System_Status_);
          //ROS_INFO("get system status");
          if (ESVO_System_Status_ == "WORKING")
          {
            std::vector<ros::Time>::reverse_iterator iter = time_pose_.rbegin();
            while ((time_pose_.size() == 0) || (time_pose_.size() == 1))
            {
              //ROS_INFO("waiting for timestamp");
              r.sleep();
              //ROS_INFO("r sleep is ok"); //continue;
            }
            while (iter != time_pose_.rend())
            {
              if (iter->toSec() < curr_.t_.toSec())
              {
                r.sleep();
                iter = time_pose_.rbegin();
                //ROS_INFO("cur time:%f", curr_.t_.toSec());
                //ROS_INFO("iter time:%f", iter->toSec());
                continue;
              }
              {
                std::lock_guard<std::mutex> lock(data_mutex_);
                while (iter->toSec() >= curr_.t_.toSec())
                {
                  if (iter != time_pose_.rend())
                  {
                    if ((++iter)->toSec() < curr_.t_.toSec())
                    {
                      temp2_.t_ = *(iter);
                      temp1_.t_ = *(--iter);
                      break;
                    }
                    continue;
                  }
                  else
                  {
                    ROS_INFO("There is no element!");
                    break;
                  }
                }
                //ROS_INFO("time:%f,%f,%f", curr_.t_.toSec(), temp2_.t_.toSec(), temp1_.t_.toSec());
                if (!getPoseAt(temp1_.t_, temp1_.tr_, dvs_frame_id_))
                {
                  LOG(INFO) << "ESVO_System_Status_: " << ESVO_System_Status_ << ", curr_.t_time_pose_1: " << curr_.t_.toNSec();
                  LOG(INFO) << "Logic error ! There must be a pose for the given timestamp, because mapping has been finished.";
                  exit(-1);
                  return false;
                }

                if (!getPoseAt(temp2_.t_, temp2_.tr_, dvs_frame_id_))
                {
                  LOG(INFO) << "ESVO_System_Status_: " << ESVO_System_Status_ << ", curr_.t_time_pose_2: " << curr_.t_.toNSec();
                  LOG(INFO) << "Logic error ! There must be a pose for the given timestamp, because mapping has been finished.";
                  exit(-1);
                  return false;
                }

                quat_s_ = Quaternion_S_lerp(temp2_.tr_.getRotation().toImplementation(), temp1_.tr_.getRotation().toImplementation(), (curr_.t_.toSec() - temp2_.t_.toSec()) / (temp1_.t_.toSec() - temp2_.t_.toSec()));
                temp_s_ = temp2_.tr_.getPosition() + (temp1_.tr_.getPosition() - temp2_.tr_.getPosition()) * ((curr_.t_.toSec() - temp2_.t_.toSec()) / (temp1_.t_.toSec() - temp2_.t_.toSec()));

                curr_.tr_ = Transformation(quat_s_, temp_s_);
                semi_dense::publishPose(curr_.t_, curr_.tr_);
                //make semi dense
                semi_dense::make_semi_dense(curr_.cur_depth_, curr_.cur_image_, curr_.cur_TS_);
                reff_.t_ = curr_.t_;

                //make sensor_msgs::pointcloud2
                //get the 3D point cloud in left camera coordinate
                //transfer the cv::Mat to the Eigen
                int row = curr_.cur_depth_->image.rows;
                int col = curr_.cur_depth_->image.cols;
                Eigen::MatrixXd depth_eigen(row, col);
                //cv::cv2eigen(curr_.cur_depth_->image, depth_eigen);
                //sensor_msgs::ImagePtr semi_dense_msg = cv_bridge::CvImage(std_msgs::Header(), "bgr8", semi_dense_).toImageMsg();
                //semi_dense_pub_.publish(*semi_dense_msg);
                cv::cv2eigen(semi_dense_, depth_eigen);

                publish_point_cloud(depth_eigen, row, col, curr_.tr_, pose_);
                publish_mask(curr_.cur_depth_, row, col);
                //semi_dense::publishPose(curr_.t_, pose_);
                //}
              }
              break;
              //continue;
            }
          }

          {
            std::lock_guard<std::mutex> lock(data_mutex_);
            nh_.getParam("/ESVO_SYSTEM_STATUS", ESVO_System_Status_);
            if (ESVO_System_Status_ == "INITIALIZATION")
            {
              curr_.tr_.setIdentity();
              //reff_.tr_.setIdentity();

              //reff_.t_ = curr_.t_;
              //semi_dense::publishPose(curr_.t_, curr_.tr_);
              //make semi dense
              semi_dense::make_semi_dense(curr_.cur_depth_, curr_.cur_image_, curr_.cur_TS_);
              reff_.t_ = curr_.t_;

              //make sensor_msgs::pointcloud2
              //get the 3D point cloud in left camera coordinate
              //transfer the cv::Mat to the Eigen
              int row = curr_.cur_depth_->image.rows;
              int col = curr_.cur_depth_->image.cols;
              Eigen::MatrixXd depth_eigen(row, col);
              //cv::cv2eigen(curr_.cur_depth_->image, depth_eigen);
              //sensor_msgs::ImagePtr semi_dense_msg = cv_bridge::CvImage(std_msgs::Header(), "bgr8", semi_dense_).toImageMsg();
              //semi_dense_pub_.publish(*semi_dense_msg);
              cv::cv2eigen(semi_dense_, depth_eigen);

              publish_point_cloud(depth_eigen, row, col, curr_.tr_, pose_);
              publish_mask(curr_.cur_depth_, row, col);
              semi_dense::publishPose(curr_.t_, pose_);
            }
          }
        }
      }
    }
    return 0;
  }

  void semi_dense::publish_mask(
      cv_bridge::CvImagePtr &depthPtr,
      int row,
      int col)
  {
    mask_ = cv::Mat::zeros(row, col, CV_32F);

    for (int i = 0; i < row; i++)
    {
      for (int j = 0; j < col; j++)
      {
        if ((depthPtr->image.at<float>(i, j) != 0) && (!isnan(depthPtr->image.at<float>(i, j)) && (!isinf(depthPtr->image.at<float>(i, j)))))
        {
          mask_.at<float>(i, j) = 1;

        }
      }
    }
    //add mask
    mask_.convertTo(mask_, CV_8UC1, 1, 0);
    cv_bridge::CvImage cv_image;
    cv_image.encoding = "mono8";
    cv_image.image = mask_;
    cv_image.header.stamp = curr_.t_;
    mask_pub_.publish(cv_image.toImageMsg());
  }

  void semi_dense::publish_point_cloud(
      Eigen::MatrixXd &depth_eigen,
      int row,
      int col,
      Transformation tr,
      Transformation &pose_pub)
  {
    pc_world_->clear();
    pc_world_->reserve(50000);
    pc_local_->clear();
    pc_local_->reserve(50000);
    //pc_temp_->clear();
    pc_temp_->reserve(50000);
    pc_global_->reserve(350000);

    //mask_ = cv::Mat::zeros(row, col, CV_8UC1);
    for (int i = 0; i < row; i++)
    {
      for (int j = 0; j < col; j++)
      {
        double d = depth_eigen(i, j);
        if ((d != 0) && (!isnan(d)))
        {
          if (d < 0.5 || d > 15)
          {
            continue;
          }

          Eigen::Matrix3d K;
          K << 199.6530123165822, 0.0, 177.43276376280926, 
          0.0, 199.6530123165822, 126.81215684365904,
          0.0,0.0,1;
          Eigen::Vector3d x_cam(j, i, 1);
          Eigen::Vector3d p_cam = depth_eigen(i, j) * K.inverse() * x_cam;

          if (!false)
          {
            Eigen::Matrix<double, 4, 4> T_world_result = tr.getTransformationMatrix();
            Eigen::Vector3d p_world = T_world_result.block<3, 3>(0, 0) * p_cam + T_world_result.block<3, 1>(0, 3);
            pc_local_->push_back(pcl::PointXYZ(p_world(0), p_world(1), p_world(2)));


            //Eigen::Vector3d p_world = curr_.tr_.getRotationMatrix().transpose() * p_cam - curr_.tr_.getRotationMatrix().transpose()*curr_.tr_.getPosition();
            //pc_local_->push_back(pcl::PointXYZ(p_world(0), p_world(1), p_world(2)));            

            //Eigen::Vector3d p_world = curr_.tr_.getRotationMatrix() * p_cam + curr_.tr_.getPosition();
            //pc_local_->push_back(pcl::PointXYZ(p_world(0), p_world(1), p_world(2)));

            //pc_local_->push_back(pcl::PointXYZ(p_cam(0), p_cam(1), p_cam(2)));
          }
        }
      }
    }

    if (pc_global_->empty())
    {
      *pc_global_ = *pc_local_;
      *pc_ref_ = *pc_local_;
      pose_pub = tr;
    }
    else
    {
      //float global_num = pc_global_->size();
      //ROS_INFO("global number:%f",global_num);
      //compute_pc_tr(pc_local_, pc_global_, pc_merge_tr_, thresh_pc_merge_);
      //compute_pc_tr(pc_local_, pc_ref_, pc_merge_tr_, thresh_pc_merge_);
      pairAlign (pc_ref_, pc_local_, pc_temp_, pc_merge_tr_, true);
      Eigen::Matrix<double, 4, 4> T_world_result = tr.getTransformationMatrix();
      Eigen::Matrix3d rotation_matrix = T_world_result.block<3, 3>(0,0) * pc_merge_tr_.block<3,3>(0,0).cast<double>().transpose();
      Eigen::Matrix<double, 3, 1> translation_vector = T_world_result.block<3,1>(0,3) - pc_merge_tr_.block<3,1>(0,3).cast<double>();

      Eigen::Quaterniond rot2quat(rotation_matrix);

      Transformation::Rotation::Implementation rotation_pub = rot2quat;
      Transformation::Position translation_pub = translation_vector;
      pose_pub = Transformation(rotation_pub, translation_pub);
      //pairAlign (pc_global_, pc_local_, pc_global_, pc_merge_tr_, true);
      //pcl::transformPointCloud(*pc_local_, *pc_temp_, pc_merge_tr_);
      //pcl::transformPointCloud(*pc_local_, *pc_temp_, pc_merge_tr_);
      /*
      PointCloud::iterator iter_pc_temp = pc_temp_->begin();
      while (iter_pc_temp != pc_temp_->end())
      {
        global_pc_number = pc_global_->size();
        if (global_pc_number > 50000)
        {
          PointCloud::iterator iter_pc_global = pc_global_->begin();
          pc_global_->erase(iter_pc_global);
          pc_global_->push_back(*iter_pc_temp);
          iter_pc_temp++;
        }
        else
        {
          pc_global_->push_back(*iter_pc_temp);
          iter_pc_temp++;
        }
      }
      ROS_INFO("Merge two point clouds");
        */
      //float global_num1 = pc_global_->size();
      //float temp_num = pc_temp_->size();
      //ROS_INFO("global number, temp number:%f%f",global_num1, temp_num);
      //*pc_ref_ = *pc_temp_;
      

      *pc_global_ = *pc_temp_ + *pc_ref_;
      //*pc_global_ = *pc_global_ + *pc_temp_;
      *pc_ref_ = *pc_temp_;

    }
    bool global = true;
    if (global)
    {
      if (!pc_global_->empty())
      {
        sensor_msgs::PointCloud2::Ptr pc_to_publish(new sensor_msgs::PointCloud2);
        pcl::toROSMsg(*pc_global_, *pc_to_publish);
        //float global_num = pc_global_->size();
        //ROS_INFO("global number:%f",global_num);
        //publish pointcloud
        pc_to_publish->header.stamp = curr_.t_;
        pc_pub_.publish(pc_to_publish);
      }
    }
    else
    {
      if (!pc_ref_->empty())
      {
        sensor_msgs::PointCloud2::Ptr pc_to_publish(new sensor_msgs::PointCloud2);
        pcl::toROSMsg(*pc_ref_, *pc_to_publish);
        //publish pointcloud
        pc_to_publish->header.stamp = curr_.t_;
        pc_pub_.publish(pc_to_publish);
      }
    }
  }
  void
  semi_dense::compute_pc_tr(const pcl::PointCloud<pcl::PointXYZ>::Ptr &input,
                            const pcl::PointCloud<pcl::PointXYZ>::Ptr &target,
                            Eigen::Matrix4f &transformation,
                            const double thresh)
  {
    pcl::SampleConsensusModelRegistration<pcl::PointXYZ>::Ptr model(new pcl::SampleConsensusModelRegistration<pcl::PointXYZ>(input));
    model->setInputTarget(target);

    pcl::RandomSampleConsensus<pcl::PointXYZ> sac(model, thresh);
    sac.setMaxIterations(100000);

    if (!sac.computeModel(2))
    {
      PCL_ERROR("Could not compute a valid transformation!\n");
      return;
    }
    Eigen::VectorXf coeff;
    sac.getModelCoefficients(coeff);
    transformation.row(0) = coeff.segment<4>(0);
    transformation.row(1) = coeff.segment<4>(4);
    transformation.row(2) = coeff.segment<4>(8);
    transformation.row(3) = coeff.segment<4>(12);
  }

/**匹配一对点云数据集并且返还结果
*参数 cloud_src 是源点云
*参数 cloud_src 是目标点云
*参数output输出的配准结果的源点云
*参数final_transform是在来源和目标之间的转换
*/
void semi_dense::pairAlign (const PointCloud::Ptr cloud_src, const PointCloud::Ptr cloud_tgt, PointCloud::Ptr output, Eigen::Matrix4f &final_transform, bool downsample)
{
    //
    //为了一致性和高速的下采样
    //注意：为了大数据集需要允许这项
    PointCloud::Ptr src (new PointCloud);
    PointCloud::Ptr tgt (new PointCloud);
    pcl::VoxelGrid<pcl::PointXYZ> grid;
    if (downsample)
    {
        grid.setLeafSize (0.05, 0.05, 0.05);
        grid.setInputCloud (cloud_src);
        grid.filter (*src);
        grid.setInputCloud (cloud_tgt);
        grid.filter (*tgt);
    }
    else
    {
        src = cloud_src;
        tgt = cloud_tgt;
    }
    //计算曲面法线和曲率
    pcl::PointCloud<pcl::PointNormal>::Ptr points_with_normals_src (new pcl::PointCloud<pcl::PointNormal>);
    pcl::PointCloud<pcl::PointNormal>::Ptr points_with_normals_tgt (new pcl::PointCloud<pcl::PointNormal>);
    pcl::NormalEstimation<pcl::PointXYZ, pcl::PointNormal> norm_est;
    pcl::search::KdTree<pcl::PointXYZ>::Ptr tree (new pcl::search::KdTree<pcl::PointXYZ> ());
    norm_est.setSearchMethod (tree);
    norm_est.setKSearch (30);
    norm_est.setInputCloud (src);
    norm_est.compute (*points_with_normals_src);
    pcl::copyPointCloud (*src, *points_with_normals_src);
    norm_est.setInputCloud (tgt);
    norm_est.compute (*points_with_normals_tgt);
    pcl::copyPointCloud (*tgt, *points_with_normals_tgt);
    //
    //举例说明我们自定义点的表示（以上定义）
    MyPointRepresentation point_representation;
    //调整'curvature'尺寸权重以便使它和x, y, z平衡
    float alpha[4] = {1.0, 1.0, 1.0, 1.0};
    point_representation.setRescaleValues (alpha);
    //
    // 配准
    pcl::IterativeClosestPointNonLinear<pcl::PointNormal, pcl::PointNormal> reg;
    reg.setTransformationEpsilon (1e-8);
    //将两个对应关系之间的(src<->tgt)最大距离设置为10厘米
    //注意：根据你的数据集大小来调整
    reg.setMaxCorrespondenceDistance (0.1);  
    //设置点表示
    reg.setPointRepresentation (boost::make_shared<const MyPointRepresentation> (point_representation));
    //reg.setInputCloud (points_with_normals_src);
    reg.setInputSource (points_with_normals_src);
    reg.setInputTarget (points_with_normals_tgt);
    //
    //在一个循环中运行相同的最优化并且使结果可视化
    Eigen::Matrix4f Ti = Eigen::Matrix4f::Identity (), prev, targetToSource;
    pcl::PointCloud<pcl::PointNormal>::Ptr reg_result = points_with_normals_src;
    reg.setMaximumIterations (30);
    for (int i = 0; i < 30; ++i)
    {
        //PCL_INFO ("Iteration Nr. %d.\n", i);
        //为了可视化的目的保存点云
        points_with_normals_src = reg_result;
        //估计
        reg.setInputSource (points_with_normals_src);
        reg.align (*reg_result);
        //在每一个迭代之间累积转换
        Ti = reg.getFinalTransformation () * Ti;
        //如果这次转换和之前转换之间的差异小于阈值
        //则通过减小最大对应距离来改善程序
        if (fabs ((reg.getLastIncrementalTransformation () - prev).sum ()) < reg.getTransformationEpsilon ())
            reg.setMaxCorrespondenceDistance (reg.getMaxCorrespondenceDistance () - 0.001);
        prev = reg.getLastIncrementalTransformation ();
        //可视化当前状态
        //showCloudsRight(points_with_normals_tgt, points_with_normals_src);
    }
    //
    // 得到目标点云到源点云的变换
    targetToSource = Ti.inverse();
    //
    //把目标点云转换回源框架
    pcl::transformPointCloud (*cloud_tgt, *output, targetToSource);
    //p->removePointCloud ("source");
    //p->removePointCloud ("target");
    //pcl::PointCloudColorHandlerCustom<PointT> cloud_tgt_h (output, 0, 255, 0);
    //PointCloudColorHandlerCustom<PointT> cloud_src_h (cloud_src, 255, 0, 0);
    //p->addPointCloud (output, cloud_tgt_h, "target", vp_2);
    //p->addPointCloud (cloud_src, cloud_src_h, "source", vp_2);
    //PCL_INFO ("Press q to continue the registration.\n");
    //p->spin ();
    //p->removePointCloud ("source"); 
    //p->removePointCloud ("target");
    //添加源点云到转换目标
    //*output += *cloud_src;
    
    final_transform = targetToSource;
}





  void semi_dense::semidenseCallback(
      const sensor_msgs::ImageConstPtr &depth_map,
      const sensor_msgs::ImageConstPtr &image,
      const sensor_msgs::ImageConstPtr &TS_left)
  {
    /* 
    semi_count;
    if (semi_count++%=0){
      do something
    }
    else {
      return;
    }
     */
    
    std::lock_guard<std::mutex> lock(data_mutex_);
    if(semi_count_%4==0)
    {
      cv_bridge::CvImagePtr cv_ptr_depth, cv_ptr_image, cv_ptr_ts;
      //ROS_INFO("get the image and depth");
      try
      {
        cv_ptr_depth = cv_bridge::toCvCopy(depth_map, sensor_msgs::image_encodings::TYPE_32FC1);
        cv_ptr_image = cv_bridge::toCvCopy(image, sensor_msgs::image_encodings::TYPE_32FC1);
        cv_ptr_ts = cv_bridge::toCvCopy(TS_left, sensor_msgs::image_encodings::MONO8);
      }
      catch (cv_bridge::Exception &e)
      {
        ROS_ERROR("cv_bridge exception: %s", e.what());
        return;
      }

      //push back the depth and image into map
      ros::Time t_depth = depth_map->header.stamp;
      string id_depth = depth_map->header.frame_id;
      time_depth_.push_back(t_depth);
      depth_mapPtr_.insert(pair<ros::Time, cv_bridge::CvImagePtr>(t_depth, cv_ptr_depth));
      image_mapPtr_.insert(pair<ros::Time, cv_bridge::CvImagePtr>(t_depth, cv_ptr_image));
      //add TS
      TS_mapPtr_.insert(pair<ros::Time, cv_bridge::CvImagePtr>(t_depth, cv_ptr_ts));
      id_map_.insert(pair<ros::Time, string>(t_depth, id_depth));

      // keep size
      while (time_depth_.size() > TIME_DEPTH_LENGTH_)
      {
        auto it_time_depth = time_depth_.begin();
        time_depth_.erase(it_time_depth);
        auto it_depth_mapPtr = depth_mapPtr_.begin();
        depth_mapPtr_.erase(it_depth_mapPtr);
        auto it_image_mapPtr = image_mapPtr_.begin();
        image_mapPtr_.erase(it_image_mapPtr);
        auto it_TS_mapPtr = TS_mapPtr_.begin();
        TS_mapPtr_.erase(it_TS_mapPtr);
      }
    }
    semi_count_++;

    
  }

  void semi_dense::stampedPoseCallback(
      const geometry_msgs::PoseStampedConstPtr &ps_msg)
  {
    std::lock_guard<std::mutex> lock(data_mutex_);
    // To check inconsistent timestamps and reset.
    //ROS_INFO("get the pose");
    static constexpr double max_time_diff_before_reset_s = 0.5;
    const ros::Time stamp_first_event = ps_msg->header.stamp;
    if (time_pose_.size() >= POSE_LENGTH_)
    {
      auto it_time_pose = time_pose_.begin();
      time_pose_.erase(it_time_pose);
    }
    if (time_pose_.size() < POSE_LENGTH_)
    {
      time_pose_.push_back(stamp_first_event);
    }
    std::string *err_tf = new std::string();
    //  int iGetLastest_common_time =
    //    tf_->getLatestCommonTime(dvs_frame_id_.c_str(), ps_msg->header.frame_id, tf_lastest_common_time_, err_tf);
    delete err_tf;
    if (tf_lastest_common_time_.toSec() != 0)
    {
      const double dt = stamp_first_event.toSec() - tf_lastest_common_time_.toSec();
      if (dt < 0 || std::fabs(dt) >= max_time_diff_before_reset_s)
      {
        ROS_INFO("Inconsistent event timestamps detected <stampedPoseCallback> (new: %f, old %f), resetting.",
                 stamp_first_event.toSec(), tf_lastest_common_time_.toSec());
        reset();
      }
    }
    // add pose to tf
    tf::Transform tf(
        tf::Quaternion(
            ps_msg->pose.orientation.x,
            ps_msg->pose.orientation.y,
            ps_msg->pose.orientation.z,
            ps_msg->pose.orientation.w),
        tf::Vector3(
            ps_msg->pose.position.x,
            ps_msg->pose.position.y,
            ps_msg->pose.position.z));
    tf::StampedTransform st(tf, ps_msg->header.stamp, ps_msg->header.frame_id, dvs_frame_id_.c_str());
    tf_->setTransform(st);
  }

  void semi_dense::make_semi_dense(
      cv_bridge::CvImagePtr &depthPtr,
      cv_bridge::CvImagePtr &imagePtr,
      cv_bridge::CvImagePtr &TSPtr)
  {
    // canny edge
    if (!imagePtr->image.empty())
    {
      if (imagePtr->image.type() == CV_32FC1)
      {
        cv::normalize(imagePtr->image, imagePtr->image, 1, 0, cv::NORM_MINMAX);
        imagePtr->image.convertTo(transfer, CV_8UC1, 255, 0);
        if (transfer.type() == CV_8UC1)
        {
          if (!transfer.data)
          {
            ROS_ERROR("transfer is empty");
          }
          else
          {
            cv::imwrite("/home/wp/zyf/transfer.png", transfer);
          }
          if (!rect_init_)
          {
            cv::Size size(346, 260);
            cv::fisheye::initUndistortRectifyMap(camera_matrix_, distortion_coefficients_, rectification_matrix_, K_new_, size, CV_32FC1, rect_x_, rect_y_);
            rect_init_ = true;
          }
          cv::remap(transfer, transfer_out, rect_x_, rect_y_, CV_INTER_LINEAR);
          cv::imwrite("/home/wp/zyf/transfer_out.png", transfer_out);
          cv::Canny(transfer_out, cannyresult, 40, 255); //these parameters may need to be changed

          //sensor_msgs::ImagePtr canny_msg = cv_bridge::CvImage(std_msgs::Header(), "bgr8", cannyresult).toImageMsg();
          //canny_pub_.publish(*canny_msg);
          if (!cannyresult.data)
          {
            ROS_ERROR("canny res is empty");
          }
          else
          {
            cv::imwrite("/home/wp/zyf/canny.png", cannyresult);
          }
        }
        //}
      }
      else if (imagePtr->image.type() == CV_8UC1)
      {
        cv::Canny(imagePtr->image, cannyresult, 40, 255); //these parameters may need to be changed
      }
      else if (imagePtr->image.type() == CV_8UC3)
      {
        cv::cvtColor(imagePtr->image, imagePtr->image, cv::COLOR_BGR2GRAY);
        cv::Canny(imagePtr->image, cannyresult, 40, 255); //these parameters may  need to be changed
      }
      else
      {
        ROS_INFO("Unknown type of image");
        cv::Mat transfer(imagePtr->image.rows, imagePtr->image.cols, CV_8UC1);
        cv::normalize(imagePtr->image, imagePtr->image, 1, 0, cv::NORM_MINMAX);
        imagePtr->image.convertTo(transfer, CV_8UC1, 255, 0);
        ROS_INFO("type is changed to CV_8UC1");
        cv::Canny(imagePtr->image, cannyresult, 40, 255); //these parameters may need to be changed
        imagePtr->image.convertTo(transfer_depth, CV_8UC1, 255, 0);
        cv::imwrite("/home/wp/zyf/transfer_depth.png", transfer_depth);
      }
    }

    else
    {
      ROS_ERROR("No image!");
    }
    //ROS_INFO("make1");
    cannyresult.convertTo(cannyresult, CV_32F);
    cv::normalize(cannyresult, cannyresult, 1, 0, cv::NORM_MINMAX);
    cv::Mat cannyresult_plus = cannyresult;
    for(int i=1; i<cannyresult.rows-1; i++)
    {
      for(int j=1; j<cannyresult.cols-1; j++)
      {
        if(cannyresult.at<float>(i,j)=1)
        {
          cannyresult_plus.at<float>(i-1,j) = 1;
          cannyresult_plus.at<float>(i+1,j) = 1;
          cannyresult_plus.at<float>(i,j-1) = 1;
          cannyresult_plus.at<float>(i,j+1) = 1;
          cannyresult_plus.at<float>(i+1,j+1) = 1;
          cannyresult_plus.at<float>(i-1,j+1) = 1;
          cannyresult_plus.at<float>(i+1,j-1) = 1;
          cannyresult_plus.at<float>(i-1,j-1) = 1;
        }
      }
    }
    cannyresult = cannyresult_plus;
    TSPtr->image.convertTo(TSPtr->image, CV_32F);
    //cv::normalize(TSPtr->image,TSPtr->image, 1, 0, cv::NORM_MINMAX);
    cv::Mat TS_mask = TSPtr->image;
    int mask_num = 0;
    for (int i = 0; i < TSPtr->image.rows; i++)
    {
      for (int j = 0; j < TSPtr->image.cols; j++)
      {
        if (TSPtr->image.at<float>(i, j) > 80)
        {
          TSPtr->image.at<float>(i, j) = 1;
          mask_num += 1;
        }
        else
        {
          TSPtr->image.at<float>(i, j) = 0;
        }
      }
    }
    if(mask_num<500)
    {
      TSPtr->image = TS_mask;
      for (int i = 0; i < TSPtr->image.rows; i++)
      {
      for (int j = 0; j < TSPtr->image.cols; j++)
      {
        if (TSPtr->image.at<float>(i, j) > 0)
        {
          TSPtr->image.at<float>(i, j) = 1;
          ROS_WARN("Use naive mask");
        }
        else
        {
          TSPtr->image.at<float>(i, j) = 0;
        }
      }
      }
    }
    bool with_rgb = true;
    if(with_rgb)
    {
      if(true)
      {
        cannyresult = TSPtr->image.mul(cannyresult);
        semi_dense_ = depthPtr->image.mul(cannyresult);
      }
      else
      {
        semi_dense_ = depthPtr->image.mul(cannyresult);
      }
      
    }
    else
    {
      semi_dense_ = depthPtr->image.mul(TSPtr->image);
    }
    cannyresult.convertTo(cannyresult, CV_8UC1, 255, 0);

    //cv::imwrite("/home/wp/zyf/depth_raw.png", depthPtr->image);
    cv::imwrite("/home/wp/zyf/canny_mask.png", cannyresult);

    imagePtr->image.convertTo(transfer_depth, CV_8UC1, 255, 0);    
    cv::imwrite("/home/wp/zyf/transfer_depth.png", transfer_depth);
  }

  void semi_dense::publishPose(const ros::Time &t, Transformation &tr)
  {
    geometry_msgs::PoseStampedPtr ps_ptr(new geometry_msgs::PoseStamped());
    ps_ptr->header.stamp = t;
    ps_ptr->header.frame_id = world_frame_id_;
    ps_ptr->pose.position.x = tr.getPosition()(0);
    ps_ptr->pose.position.y = tr.getPosition()(1);
    ps_ptr->pose.position.z = tr.getPosition()(2);
    ps_ptr->pose.orientation.x = tr.getRotation().x();
    ps_ptr->pose.orientation.y = tr.getRotation().y();
    ps_ptr->pose.orientation.z = tr.getRotation().z();
    ps_ptr->pose.orientation.w = tr.getRotation().w();
    pose_pub_.publish(ps_ptr);
    //ROS_INFO("publish the pose successful");
  }
  bool
  semi_dense::getPoseAt(
      const ros::Time &t, esvo_core::Transformation &Tr, const std::string &source_frame)
  {
    std::string *err_msg = new std::string();
    if (!tf_->canTransform(world_frame_id_, source_frame, t, err_msg))
    {
      LOG(WARNING) << t.toNSec() << " : " << *err_msg;
      delete err_msg;
      return false;
    }
    else
    {
      //ROS_INFO("getposeAT0");
      tf::StampedTransform st;
      //ROS_INFO("getposeAT1");
      tf_->lookupTransform(world_frame_id_, source_frame, t, st);
      //ROS_INFO("getposeAT2");
      tf::transformTFToKindr(st, &Tr);
      //ROS_INFO("getposeAT3");
      return true;
    }
  }

  //Eigen::Quaterniond
  Transformation::Rotation::Implementation
  semi_dense::Quaternion_S_lerp(Eigen::Quaterniond &start_q, Eigen::Quaterniond &end_q, double t)
  {
    Eigen::Quaterniond lerp_q;

    double cos_angle = start_q.x() * end_q.x() + start_q.y() * end_q.y() + start_q.z() * end_q.z() + start_q.w() * end_q.w();

    // If the dot product is negative, the quaternions have opposite handed-ness and slerp won't take
    // the shorter path. Fix by reversing one quaternion.
    if (cos_angle < 0)
    {
      end_q.x() = -end_q.x();
      end_q.y() = -end_q.y();
      end_q.z() = -end_q.z();
      end_q.w() = -end_q.w();
      cos_angle = -cos_angle;
    }

    double ratio_A, ratio_B;
    //if the inputs are too close for comfort, linearly interpolate
    if (cos_angle > 0.99995f)
    {
      ratio_A = 1.0f - t;
      ratio_B = t;
    }
    else
    {
      double sin_angle = sqrt(1.0f - cos_angle * cos_angle);
      double angle = atan2(sin_angle, cos_angle);
      ratio_A = sin((1.0f - t) * angle) / sin_angle;
      ratio_B = sin(t * angle) / sin_angle;
    }

    lerp_q.x() = ratio_A * start_q.x() + ratio_B * end_q.x();
    lerp_q.y() = ratio_A * start_q.y() + ratio_B * end_q.y();
    lerp_q.z() = ratio_A * start_q.z() + ratio_B * end_q.z();
    lerp_q.w() = ratio_A * start_q.w() + ratio_B * end_q.w();

    return lerp_q.normalized();
  }

  void semi_dense::reset()
  {
    // mutual-thread communication with MappingThread.
    LOG(INFO) << "Coming into reset()";
    reset_promise_.set_value();
    LOG(INFO) << "(reset) The mapping thread future is waiting for the value.";
    mapping_thread_future_.get();
    LOG(INFO) << "(reset) The mapping thread future receives the value.";

    // clear all maintained data
    tf_->clear();
    pc_world_->clear();

    for (int i = 0; i < 2; i++)
      LOG(INFO) << "****************************************************";
    LOG(INFO) << "****************** RESET THE SYSTEM *********************";
    for (int i = 0; i < 2; i++)
      LOG(INFO) << "****************************************************\n\n";

    // restart the mapping thread
    reset_promise_ = std::promise<void>();
    mapping_thread_promise_ = std::promise<void>();
    reset_future_ = reset_promise_.get_future();
    mapping_thread_future_ = mapping_thread_promise_.get_future();
    ESVO_System_Status_ = "INITIALIZATION";
    nh_.setParam("/ESVO_SYSTEM_STATUS", ESVO_System_Status_);
    std::thread MakeSDThread(&semi_dense::MakeSDLoop, this,
                             std::move(mapping_thread_promise_), std::move(reset_future_));
    MakeSDThread.detach();
  }
} // esvo_core
