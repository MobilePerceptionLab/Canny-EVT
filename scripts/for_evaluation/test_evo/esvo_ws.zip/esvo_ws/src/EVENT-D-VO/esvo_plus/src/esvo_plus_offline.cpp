#include <esvo_plus/esvo_plus_offline.h>

namespace esvo_plus
{
namespace offline
{
/* type traits */

using namespace esvo_plus::types;

/* system variables */

ros::NodeHandle *sys_nh;

image_transport::ImageTransport *sys_it;

image_transport::Publisher pub_ts;
image_transport::Publisher pub_rgb;
image_transport::Publisher pub_depth;
image_transport::Publisher pub_aux;
image_transport::Publisher pub_repj;
ros::Publisher             pub_semi_dense;
ros::Publisher             pub_pose;
ros::Publisher             pub_path;
ros::Publisher             pub_gt;

nav_msgs::Path                                                                                path;
nav_msgs::Path                                                                                gt_path;
bool                                                                                          bSaveTrajectory = true;
std::list<Eigen::Matrix<double, 4, 4>, Eigen::aligned_allocator<Eigen::Matrix<double, 4, 4>>> lPose;
std::list<std::string>                                                                        lTimestamp;
/* configuration */

std::string bag_path;
std::string resultPath;

std::string depth_topic;
std::string event_topic;
std::string rgb_topic;

std::string distortion_model; /* equdistant and plumb_bob */

std::string ts_mode; /* currently unused */

std::string depth_mode; /* currently unused */

Eigen::Matrix3d K_ev;
Eigen::Matrix3d K_ev_inv;

Eigen::Matrix<double, 3, 4> P_ev;

Eigen::Matrix3d K_rgb;
Eigen::Matrix3d K_rgb_inv;

Eigen::Matrix3d K_depth;
Eigen::Matrix3d K_depth_inv;

Eigen::Matrix4d T_w_rgb;     /* rgb camera to world */
Eigen::Matrix4d T_rgb_depth; /* depth camera to rgb camera */
Eigen::Matrix4d T_ev_depth;  /* depth camera to event camera */

cv::Mat dist_ev;
cv::Mat dist_rgb;
cv::Mat dist_depth;

std::string gt_topic = "/davis/left/pose";

int height_ev, height_depth, height_rgb;
int width_ev, width_depth, width_rgb;

double tolerant_msec; /* currently unused */

bool verbose   = false;
bool visualize = false;

bool bcreate_ts = true;
bool bcreate_ac = false;

int with_ICP; /* whether to use ICP method */

int with_event; /* whether to use initial guess from event */

int ignore_polarity;

int depth_downsample_factor;

int depth_downsample_count;

int ts_generate_factor; /* currently unused */

double ts_decay_factor;

double ac_accumulated_time;

std::string calib_dir;

/* message queue */

std::deque<Event>   queue_ev;
std::deque<cv::Mat> queue_ts; /* currently unused */

std::deque<sensor_msgs::Image>         queue_rgb;
std::deque<sensor_msgs::Image>         queue_depth;
std::deque<geometry_msgs::PoseStamped> queue_gt;

std::deque<PointCloud>  queue_pc;  /* point cloud in reference view with size 2 for ICP */
std::deque<PointCloud>  queue_sd;  /* queue of semidense point cloud */
std::vector<EventQueue> event_mat; /* for time surface map generation */

/* pre-computed data */

Eigen::Matrix2Xd precomputed_rectified_points; /* currently unused */

cv::Mat undistort_map_ev1;
cv::Mat undistort_map_ev2;
cv::Mat undistort_map_rgb1;
cv::Mat undistort_map_rgb2;
cv::Mat undistort_map_depth1;
cv::Mat undistort_map_depth2;

/* utils functions */

static auto create_ts = []( const ros::Time &t, cv::Mat &ts ) {
  constexpr auto eq_comp = []( const Event &a, const ros::Time &b ) -> bool { return a.ts < b; };

  ts = cv::Mat::zeros( height_ev, width_ev, CV_32F );

#pragma omp parallel for
  for ( int y = 0; y < height_ev; y++ )
    {
      for ( int x = 0; x < width_ev; x++ )
        {
          const EventQueue &eq = event_mat[x + y * width_ev];

          auto it = std::lower_bound( eq.begin(), eq.end(), t, eq_comp );

          if ( it == eq.end() || it == eq.begin() )
            continue;

          it                   = it - 1;
          const float dt       = ( t - it->ts ).toSec();
          const float expVal   = std::exp( -dt / ts_decay_factor );
          ts.at<float>( y, x ) = expVal;
        }
    }
  bool median_blur = false;
  if ( median_blur )
    {
      cv::medianBlur( ts, ts, 3 );
    }
  cv::remap( ts, ts, undistort_map_ev1, undistort_map_ev2, CV_INTER_LINEAR );
};

static auto create_ac = []( const ros::Time &t, cv::Mat &ac ) {
  constexpr auto eq_comp = []( const Event &a, const ros::Time &b ) -> bool { return a.ts < b; };

  ac = cv::Mat::zeros( height_ev, width_ev, CV_32F );

#pragma omp parallel for
  for ( int y = 0; y < height_ev; y++ )
    {
      for ( int x = 0; x < width_ev; x++ )
        {
          const EventQueue &eq = event_mat[x + y * width_ev];

          auto it = std::lower_bound( eq.begin(), eq.end(), t, eq_comp );

          if ( it == eq.end() || it == eq.begin() )
            continue;

          it             = it - 1;
          const float dt = ( t - it->ts ).toSec();
          if ( dt < ac_accumulated_time )
            ac.at<float>( y, x ) = 1;
        }
    }
  bool median_blur = false;
  if ( median_blur )
    {
      cv::medianBlur( ac, ac, 3 );
    }
  cv::remap( ac, ac, undistort_map_ev1, undistort_map_ev2, CV_INTER_LINEAR );
};

/* load configuration */

void prelude( std::string &config_path )
{
  cv::FileStorage fs( config_path, cv::FileStorage::READ );

  ROS_INFO( "open file %s ...", config_path.c_str() );

  if ( !fs.isOpened() )
    ROS_FATAL( "can not find config file" );

  cv::cv2eigen( fs["K_ev"].mat(), K_ev );
  cv::cv2eigen( fs["K_rgb"].mat(), K_rgb );
  cv::cv2eigen( fs["K_depth"].mat(), K_depth );
  cv::cv2eigen( fs["T_rgb_depth"].mat(), T_rgb_depth );
  cv::cv2eigen( fs["T_ev_depth"].mat(), T_ev_depth );
  cv::cv2eigen( fs["P_ev"].mat(), P_ev );

  K_ev_inv    = K_ev.inverse();
  K_rgb_inv   = K_rgb.inverse();
  K_depth_inv = K_depth.inverse();

  dist_ev    = fs["dist_ev"].mat();
  dist_rgb   = fs["dist_rgb"].mat();
  dist_depth = fs["dist_depth"].mat();

  depth_topic = fs["depth_topic"].string();
  event_topic = fs["event_topic"].string();
  rgb_topic   = fs["rgb_topic"].string();

  height_depth = fs["height_depth"];
  height_ev    = fs["height_ev"];
  height_rgb   = fs["height_rgb"];

  width_depth = fs["width_depth"];
  width_ev    = fs["width_ev"];
  width_rgb   = fs["width_rgb"];

  tolerant_msec = fs["tolerant_msec"];

  distortion_model = fs["distortion_model"].string();

  depth_downsample_factor = fs["depth_downsample_factor"];

  depth_downsample_count = 0;

  ts_decay_factor = fs["ts_decay_factor"];

  ac_accumulated_time = fs["ac_accumulated_time"];

  ignore_polarity = fs["ignore_polarity"];

  ts_mode = fs["ts_mode"].string();

  depth_mode = fs["depth_mode"].string();

  bag_path = fs["bag_path"].string();

  resultPath = fs["resultPath"].string();

  with_ICP = fs["with_ICP"];

  with_event = fs["with_event"];

  calib_dir = fs["calib_dir"].string();

  if ( verbose )
    {
      std::cout << "[Config] " << K_ev << std::endl;
      std::cout << "[Config] " << K_rgb << std::endl;
      std::cout << "[Config] " << K_depth << std::endl;

      std::cout << "[Config] " << T_rgb_depth << std::endl;
      std::cout << "[Config] " << T_ev_depth << std::endl;

      std::cout << "[Config] " << dist_ev << std::endl;
      std::cout << "[Config] " << dist_rgb << std::endl;
      std::cout << "[Config] " << dist_depth << std::endl;

      std::cout << "[Config] " << depth_topic << std::endl;
      std::cout << "[Config] " << event_topic << std::endl;
      std::cout << "[Config] " << rgb_topic << std::endl;

      std::cout << "[Config] " << height_depth << std::endl;
      std::cout << "[Config] " << height_ev << std::endl;
      std::cout << "[Config] " << height_rgb << std::endl;

      std::cout << "[Config] " << width_rgb << std::endl;
      std::cout << "[Config] " << width_rgb << std::endl;
      std::cout << "[Config] " << width_rgb << std::endl;

      std::cout << "[Config] " << tolerant_msec << std::endl;

      std::cout << "[Config] " << distortion_model << std::endl;

      std::cout << "[Config] " << depth_downsample_factor << std::endl;

      std::cout << "[Config] " << ts_decay_factor << std::endl;

      std::cout << "[Config] " << ignore_polarity << std::endl;

      std::cout << "[Config] " << ts_mode << std::endl;

      std::cout << "[Config] " << depth_mode << std::endl;

      std::cout << "[Config] " << bag_path << std::endl;
    }

  /* calculate precomputed_rectified_points */

  precomputed_rectified_points = Eigen::Matrix2Xd( 2, height_ev * width_ev );

  cv::Mat_<cv::Point2f> raw_coord( 1, height_ev * width_ev );

  for ( int y = 0; y < height_ev; y++ )
    {
      for ( int x = 0; x < width_ev; x++ )
        {
          int index = y * width_ev + x;

          raw_coord( index ) = cv::Point2f( (float)x, (float)y );
        }
    }

  /* undistorted-rectified coordinates */

  cv::Mat_<cv::Point2f> rect_coord( 1, height_ev * width_ev );

  if ( distortion_model == "plumb_bob" )
    {
      cv::Mat R = cv::Mat::zeros( 3, 3, CV_32FC1 );

      R.at<float>( 0, 0 ) = 1.f;
      R.at<float>( 1, 1 ) = 1.f;
      R.at<float>( 2, 2 ) = 1.f;

      /* event camera */

      cv::Mat cv_K_ev, cv_P_ev;

      cv::eigen2cv( P_ev, cv_P_ev );
      cv::eigen2cv( K_ev, cv_K_ev );

      cv::undistortPoints( raw_coord, rect_coord, cv_K_ev, dist_ev );
      cv::initUndistortRectifyMap( cv_K_ev, dist_ev, R, cv_P_ev, cv::Size( width_ev, height_ev ), CV_32FC1, undistort_map_ev1, undistort_map_ev2 );

      /* rgb camera */

      cv::Mat cv_K_rgb, P_rgb;
      cv::eigen2cv( K_rgb, cv_K_rgb );

      P_rgb = cv::getOptimalNewCameraMatrix( cv_K_rgb, dist_rgb, cv::Size( width_rgb, height_rgb ), 0 );

      cv::initUndistortRectifyMap( cv_K_rgb, dist_rgb, R, P_rgb, cv::Size( width_rgb, height_rgb ), CV_32FC1, undistort_map_rgb1, undistort_map_rgb2 );

      /* depth camera */

      cv::Mat cv_K_depth, P_depth;
      cv::eigen2cv( K_depth, cv_K_depth );

      P_depth = cv::getOptimalNewCameraMatrix( cv_K_depth, dist_depth, cv::Size( width_depth, height_depth ), 0 );
      cv::initUndistortRectifyMap( cv_K_depth, dist_depth, R, P_depth, cv::Size( width_depth, height_depth ), CV_32FC1, undistort_map_depth1, undistort_map_depth2 );
    }
  else if ( distortion_model == "equidistant" )
    {
      cv::Mat R = cv::Mat::zeros( 3, 3, CV_32FC1 );

      R.at<float>( 0, 0 ) = 1.f;
      R.at<float>( 1, 1 ) = 1.f;
      R.at<float>( 2, 2 ) = 1.f;

      /* event camera */

      cv::Mat cv_K_ev, cv_P_ev;

      cv::eigen2cv( P_ev, cv_P_ev );
      cv::eigen2cv( K_ev, cv_K_ev );

      cv::fisheye::undistortPoints( raw_coord, rect_coord, cv_K_ev, dist_ev );
      cv::fisheye::initUndistortRectifyMap( cv_K_ev, dist_ev, R, cv_P_ev, cv::Size( width_ev, height_ev ), CV_32FC1, undistort_map_ev1, undistort_map_ev2 );

      /* rgb camera */

      cv::Mat cv_K_rgb, P_rgb;
      cv::eigen2cv( K_rgb, cv_K_rgb );

      P_rgb = cv::getOptimalNewCameraMatrix( cv_K_rgb, dist_rgb, cv::Size( width_rgb, height_rgb ), 0 );

      cv::fisheye::initUndistortRectifyMap( cv_K_rgb, dist_rgb, R, P_rgb, cv::Size( width_rgb, height_rgb ), CV_32FC1, undistort_map_rgb1, undistort_map_rgb2 );

      /* depth camera */

      cv::Mat cv_K_depth, P_depth;
      cv::eigen2cv( K_depth, cv_K_depth );

      P_depth = cv::getOptimalNewCameraMatrix( cv_K_depth, dist_depth, cv::Size( width_depth, height_depth ), 0 );
      cv::fisheye::initUndistortRectifyMap( cv_K_depth, dist_depth, R, P_depth, cv::Size( width_depth, height_depth ), CV_32FC1, undistort_map_depth1, undistort_map_depth2 );
    }
  else
    {
      ROS_FATAL( "unknown distortion model is provided..." );
      exit( -1 );
    }

  for ( size_t i = 0; i < height_ev * width_ev; i++ )
    {
      precomputed_rectified_points.col( i ) = Eigen::Matrix<double, 2, 1>( rect_coord( i ).x, rect_coord( i ).y );
    }

  ROS_INFO( "undistorted-rectified look-up table has been computed..." );

  /* initialize event map */

  event_mat = std::vector<EventQueue>( height_ev * width_ev );

  fs.release();
}

void init( ros::NodeHandle *nh, image_transport::ImageTransport *it )
{
  ROS_INFO( "init esvo plus system..." );

  sys_nh = nh;

  sys_it = it;

  pub_ts = sys_it->advertise( "esvo_plus/ts", 10 );

  pub_rgb = sys_it->advertise( "esvo_plus/rgb", 10 );

  pub_depth = sys_it->advertise( "esvo_plus/depth", 10 );

  pub_aux = sys_it->advertise( "esvo_plus/aux", 10 );

  pub_repj = sys_it->advertise( "esvo_plus/repj", 1 );

  pub_semi_dense = sys_nh->advertise<sensor_msgs::PointCloud2>( "esvo_plus/semi_dense", 10 );

  pub_pose = sys_nh->advertise<geometry_msgs::PoseStamped>( "/esvo_plus/pose", 10 );

  pub_path = sys_nh->advertise<nav_msgs::Path>( "/esvo_plus/trajectory", 10 );

  pub_gt = sys_nh->advertise<nav_msgs::Path>( "/esvo_plus/trajectory_gt", 10 );
}

/**
 * @param cloud_src
 * @param cloud_tgt
 * @param output transformed target point cloud (into source frame)
 * @param init_transform transformation from source to target
 * @param final_transform
 * @param downsample
 */

void ICP( const PointCloud::Ptr cloud_src, const PointCloud::Ptr cloud_tgt, PointCloud::Ptr output, Eigen::Matrix4f &final_transform, bool downsample )
{
  //
  //为了一致性和高速的下采样
  //注意：为了大数据集需要允许这项
  PointCloud::Ptr               src( new PointCloud );
  PointCloud::Ptr               tgt( new PointCloud );
  pcl::VoxelGrid<pcl::PointXYZ> grid;
  if ( downsample )
    {
      grid.setLeafSize( 0.05, 0.05, 0.05 );
      grid.setInputCloud( cloud_src );
      grid.filter( *src );
      grid.setInputCloud( cloud_tgt );
      grid.filter( *tgt );
    }
  else
    {
      src = cloud_src;
      tgt = cloud_tgt;
    }
  //计算曲面法线和曲率
  pcl::PointCloud<pcl::PointNormal>::Ptr                 points_with_normals_src( new pcl::PointCloud<pcl::PointNormal> );
  pcl::PointCloud<pcl::PointNormal>::Ptr                 points_with_normals_tgt( new pcl::PointCloud<pcl::PointNormal> );
  pcl::NormalEstimation<pcl::PointXYZ, pcl::PointNormal> norm_est;
  pcl::search::KdTree<pcl::PointXYZ>::Ptr                tree( new pcl::search::KdTree<pcl::PointXYZ>() );
  norm_est.setSearchMethod( tree );
  norm_est.setKSearch( 30 );
  norm_est.setInputCloud( src );
  norm_est.compute( *points_with_normals_src );
  pcl::copyPointCloud( *src, *points_with_normals_src );
  norm_est.setInputCloud( tgt );
  norm_est.compute( *points_with_normals_tgt );
  pcl::copyPointCloud( *tgt, *points_with_normals_tgt );
  //
  //举例说明我们自定义点的表示（以上定义）
  MyPointRepresentation point_representation;
  //调整'curvature'尺寸权重以便使它和x, y, z平衡
  float alpha[4] = { 1.0, 1.0, 1.0, 1.0 };
  point_representation.setRescaleValues( alpha );
  //
  // 配准
  pcl::IterativeClosestPointNonLinear<pcl::PointNormal, pcl::PointNormal> reg;
  reg.setTransformationEpsilon( 1e-8 );
  //将两个对应关系之间的(src<->tgt)最大距离设置为10厘米
  //注意：根据你的数据集大小来调整
  reg.setMaxCorrespondenceDistance( 0.1 );
  //设置点表示
  reg.setPointRepresentation( boost::make_shared<const MyPointRepresentation>( point_representation ) );
  // reg.setInputCloud (points_with_normals_src);
  reg.setInputSource( points_with_normals_src );
  reg.setInputTarget( points_with_normals_tgt );
  //
  //在一个循环中运行相同的最优化并且使结果可视化
  Eigen::Matrix4f                        Ti         = Eigen::Matrix4f::Identity(), prev, targetToSource;
  pcl::PointCloud<pcl::PointNormal>::Ptr reg_result = points_with_normals_src;
  reg.setMaximumIterations( 30 );
  for ( int i = 0; i < 30; ++i )
    {
      // PCL_INFO ("Iteration Nr. %d.\n", i);
      //为了可视化的目的保存点云
      points_with_normals_src = reg_result;
      //估计
      reg.setInputSource( points_with_normals_src );
      reg.align( *reg_result );
      //在每一个迭代之间累积转换
      Ti = reg.getFinalTransformation() * Ti;
      //如果这次转换和之前转换之间的差异小于阈值
      //则通过减小最大对应距离来改善程序
      if ( fabs( ( reg.getLastIncrementalTransformation() - prev ).sum() ) < reg.getTransformationEpsilon() )
        reg.setMaxCorrespondenceDistance( reg.getMaxCorrespondenceDistance() - 0.001 );
      prev = reg.getLastIncrementalTransformation();
      //可视化当前状态
      // showCloudsRight(points_with_normals_tgt, points_with_normals_src);
    }
  //
  // 得到目标点云到源点云的变换
  targetToSource = Ti.inverse();
  //
  //把目标点云转换回源框架
  pcl::transformPointCloud( *cloud_tgt, *output, targetToSource );
  // p->removePointCloud ("source");
  // p->removePointCloud ("target");
  // pcl::PointCloudColorHandlerCustom<PointT> cloud_tgt_h (output, 0, 255, 0);
  // PointCloudColorHandlerCustom<PointT> cloud_src_h (cloud_src, 255, 0, 0);
  // p->addPointCloud (output, cloud_tgt_h, "target", vp_2);
  // p->addPointCloud (cloud_src, cloud_src_h, "source", vp_2);
  // PCL_INFO ("Press q to continue the registration.\n");
  // p->spin ();
  // p->removePointCloud ("source");
  // p->removePointCloud ("target");
  //添加源点云到转换目标
  //*output += *cloud_src;

  final_transform = targetToSource;
}

void main()
{
  ROS_INFO( "start main loop..." );

  unsetVisualize();

  if ( visualize )
    {
      ROS_INFO( "play back dataset..." );

      ros::Rate r( 15 );

      for ( int i = 0; i < queue_depth.size(); i++ )
        {
          pub_depth.publish( queue_depth[i] );
          pub_rgb.publish( queue_rgb[i] );
          r.sleep();
        }
    }

  ROS_INFO( "start preprocessing..." );

  /* create event mat */
  size_t n_ev = queue_ev.size();

  for ( int i = 0; i < n_ev; i++ )
    {
      Event e = queue_ev.front();
      queue_ev.pop_front();
      event_mat[e.x + e.y * width_ev].push_back( e );
    }

  ROS_INFO( "start creating timeline..." );

  std::vector<Flags> timeline;

  for ( int i = 0; i < queue_depth.size(); i++ )
    {
      Flags f;

      f.ts   = queue_depth[i].header.stamp;
      f.TS   = true;
      f.SD   = true;
      f.ED   = true;
      f.ICP  = true;
      f.INIT = true;

      timeline.push_back( f );
    }

  /* set initial state */
  timeline[0].INIT = false;
  timeline[0].ED   = false;
  timeline[0].ICP  = false;

  constexpr int ts_interp_factor = 3;

  for ( int i = 1; i < queue_depth.size(); i++ )
    {
      Flags f;

      f.TS   = true;
      f.SD   = false;
      f.ED   = true;
      f.ICP  = false;
      f.INIT = true;

      for ( int j = 1; j < ts_interp_factor; j++ )
        {
          double t = double( j ) / double( ts_interp_factor ) * timeline[i - 1].ts.toSec() + double( ts_interp_factor - j ) / double( ts_interp_factor ) * timeline[i].ts.toSec();
          f.ts     = ros::Time().fromSec( t );
          timeline.push_back( f );
        }
    }

  std::sort( timeline.begin(), timeline.end(), []( const Flags &a, const Flags &b ) { return a.ts < b.ts; } );

  /* generate point cloud */

  queue_pc.assign( queue_depth.size(), PointCloud() );

#pragma omp parallel for
  for ( int i = 0; i < queue_depth.size(); i++ )
    {
      PointCloud &          pc_temp   = queue_pc[i];
      cv_bridge::CvImagePtr img_ptr   = cv_bridge::toCvCopy( queue_depth[i], queue_depth[i].encoding );
      cv::Mat &             depth_img = img_ptr->image;
      // cv::remap( depth_img, depth_img, undistort_map_depth1, undistort_map_depth2, CV_INTER_LINEAR );

      for ( int y = 0; y < height_depth; y++ )
        {
          for ( int x = 0; x < width_depth; x++ )
            {
              const double d = depth_img.at<float>( y, x );

              if ( d < 0.1f || isnan( d ) )
                continue;

              Eigen::Vector3d p_depth_2d_h( x, y, 1 );
              Eigen::Vector3d p_depth_3d = d * K_depth_inv * p_depth_2d_h;

              Point p( p_depth_3d( 0 ), p_depth_3d( 1 ), p_depth_3d( 2 ) );
              pc_temp.push_back( p );
            }
        }
    }
  ROS_INFO( "start estimating poses..." );

  setVerbose();
  setVisualize();

  int    depth_count = 0;
  size_t ts_count    = 0;

  cv_bridge::CvImage time_surface;

  PointCloud pc_for_icp_old;
  // PointCloud pc_for_icp_old_sd;
  // PointCloud pc_for_icp_cur_sd;

  esvo_core::core::RefFrame ref_frame;
  esvo_core::core::CurFrame cur_frame;

  esvo_core::container::CameraSystem::Ptr        CamSystemPtr( new esvo_core::container::CameraSystem( calib_dir, true, false ) );
  esvo_core::core::RegProblemConfig::Ptr         rpConfigPtr( new esvo_core::core::RegProblemConfig( 1, 1, 5, "Huber", 50.0, 0.16, 1.0, 1000, 2000, 300, 10 ) );
  std::shared_ptr<esvo_core::core::RegProblemLM> regProblemPtr = std::make_shared<esvo_core::core::RegProblemLM>( CamSystemPtr, rpConfigPtr, 4 );
  esvo_core::core::RegProblemType                rpType        = esvo_core::core::REG_ANALYTICAL;
  esvo_core::core::RegProblemSolverLM            rpSolver( CamSystemPtr, rpConfigPtr, rpType, 2 );
  if ( visualize )
    {
      rpSolver.setRegPublisher( &pub_repj );
    }

  for ( auto &t : timeline )
    {
      // getchar();
      if ( t.TS )
        {
          /* create time surface map */
          if ( bcreate_ts )
            {
              create_ts( t.ts, time_surface.image );
              time_surface.image = 255 * time_surface.image;
              time_surface.image.convertTo( time_surface.image, CV_8U );
              time_surface.encoding     = "mono8";
              time_surface.header.stamp = t.ts;

              if ( visualize )
                pub_ts.publish( time_surface.toImageMsg() );
            }

          if ( bcreate_ac )
            {
              create_ac( t.ts, time_surface.image );
              time_surface.image = 255 * time_surface.image;
              time_surface.image.convertTo( time_surface.image, CV_8U );
              time_surface.encoding     = "mono8";
              time_surface.header.stamp = t.ts;

              if ( visualize )
                pub_ts.publish( time_surface.toImageMsg() );
            }
        }

      if ( t.ED && t.INIT )
        {
          /* estimate pose by event and semi dense point cloud */

          cur_frame.numEventsSinceLastObs_ = 10000;
          ROS_WARN( "OK at %s %d", __FILE__, __LINE__ );
          if ( cur_frame.pTsObs_ != nullptr )
            {
              delete cur_frame.pTsObs_;
              cur_frame.pTsObs_ = nullptr;
            }

          cv_bridge::CvImagePtr time_surface_ptr( new cv_bridge::CvImage() );
          time_surface_ptr->image = time_surface.image.clone();
          cur_frame.pTsObs_       = new esvo_core::TimeSurfaceObservation( time_surface_ptr, time_surface_ptr, ts_count++ );
          cur_frame.t_            = t.ts;
          ROS_WARN( "OK at %s %d", __FILE__, __LINE__ );
          size_t numPoint = ref_frame.vPointXYZPtr_.size();
          rpSolver.resetRegProblem( &ref_frame, &cur_frame );
          if ( rpType == esvo_core::core::REG_NUMERICAL )
            rpSolver.solve_numerical();
          if ( rpType == esvo_core::core::REG_ANALYTICAL )
            rpSolver.solve_analytical();
          ROS_WARN( "OK at %s %d", __FILE__, __LINE__ );
          if ( bSaveTrajectory && t.SD )
            {
              lTimestamp.push_back( std::to_string( t.ts.toSec() ) );
              lPose.push_back( cur_frame.tr_.getTransformationMatrix() );
            }
        }
      if ( t.ICP && t.INIT )
        {

          if ( with_ICP )
            {
              /* estimate pose by ICP */

              PointCloud     pc_for_icp_cur = queue_pc[depth_count];
              PointCloud     pc_for_icp_temp;
              Transformation T_ref_cur = ref_frame.tr_.inverse() * cur_frame.tr_; /* transformation from target to source equivalent to Ti.inverse() */

              ROS_WARN( "OK at %s %d", __FILE__, __LINE__ );
              Eigen::Matrix4f init_pose;
              if ( with_event )
                {
                  // init_pose = T_ref_cur.inverse().getTransformationMatrix().cast<float>();
                  pcl::transformPointCloud( pc_for_icp_cur, pc_for_icp_temp, T_ref_cur.getTransformationMatrix() );
                }
              else
                {
                  // init_pose.setIdentity();
                  pc_for_icp_temp = pc_for_icp_cur;
                }
              ROS_WARN( "OK at %s %d", __FILE__, __LINE__ );
              Eigen::Matrix4f T_source_target;
              PointCloud::Ptr pc_for_icp_temp_ptr( new PointCloud( pc_for_icp_temp ) );
              // PointCloud::Ptr pc_for_icp_cur_ptr( new PointCloud( pc_for_icp_cur_sd ) );
              PointCloud::Ptr pc_for_icp_old_ptr( new PointCloud( pc_for_icp_old ) );
              // PointCloud::Ptr pc_for_icp_old_ptr( new PointCloud( pc_for_icp_old_sd ) );
              PointCloud::Ptr pc_output( new PointCloud );
              ROS_WARN( "OK at %s %d", __FILE__, __LINE__ );
              ICP( pc_for_icp_old_ptr, pc_for_icp_temp_ptr, pc_output, T_source_target, true );
              ROS_WARN( "OK at %s %d", __FILE__, __LINE__ );
              pc_for_icp_old.swap( pc_for_icp_cur );
              // pc_for_icp_old_sd.swap( pc_for_icp_cur_sd );

              Eigen::Matrix4d T_sour_tar = T_source_target.cast<double>();
              ROS_WARN( "OK at %s %d", __FILE__, __LINE__ );
              Eigen::Matrix3d             R_sour_tar = T_sour_tar.block<3, 3>( 0, 0 );
              Eigen::Matrix<double, 3, 1> t_sour_tar = T_sour_tar.block<3, 1>( 0, 3 );
              Eigen::Quaterniond          rot2quat( R_sour_tar );
              rot2quat.normalize();
              ROS_WARN( "OK at %s %d", __FILE__, __LINE__ );
              Transformation T_s_t = Transformation( rot2quat, t_sour_tar );
              ROS_WARN_STREAM( " relative pose:\n"
                               << T_ref_cur.getTransformationMatrix() << "\nref pose:\n"
                               << ref_frame.tr_.getTransformationMatrix() << "\ncur pose:\n"
                               << cur_frame.tr_.getTransformationMatrix() << "\nicp incremental pose:\n"
                               << T_s_t.getTransformationMatrix() );
              // ref_frame.tr_ = cur_frame.tr_ * T_s_t.inverse();
              ref_frame.tr_ = cur_frame.tr_ * T_s_t;
              cur_frame.tr_ = ref_frame.tr_;
              ROS_WARN( "OK at %s %d", __FILE__, __LINE__ );
              // publishPose( t.ts, cur_frame.tr_ );
              // publishPath( t.ts, cur_frame.tr_ );
            } // bool ICP=true
          else
            {
              ref_frame.tr_ = cur_frame.tr_;
            }

          publishPose( t.ts, ref_frame.tr_ );
          publishPath( t.ts, ref_frame.tr_ );
        }

      if ( t.SD )
        {
          /* create semi dense point cloud */
          PointCloud pc_ev;
          pcl::transformPointCloud( queue_pc[depth_count], pc_ev, T_ev_depth, false );
          Eigen::Matrix3d P_ev_d = P_ev.block<3, 3>( 0, 0 );
          for ( auto p_ptr : ref_frame.vPointXYZPtr_ )
            {
              delete p_ptr;
            }
          ref_frame.vPointXYZPtr_.clear();

          Eigen::Matrix<double, 4, 4> T_world_result = ref_frame.tr_.getTransformationMatrix();
          // Eigen::Vector3d p_world = T_world_result.block<3, 3>(0, 0) * p_cam + T_world_result.block<3, 1>(0, 3);
          // pc_local_->push_back(pcl::PointXYZ(p_world(0), p_world(1), p_world(2)));
          ROS_WARN( "OK at %s %d", __FILE__, __LINE__ );
          for ( auto p : pc_ev )
            {
              Eigen::Vector3d p_ev_3d( p.x, p.y, p.z );
              Eigen::Vector3d p_ev_2d_h = P_ev_d * p_ev_3d;
              const int       x         = int( round( p_ev_2d_h( 0 ) / p_ev_2d_h( 2 ) ) );
              const int       y         = int( round( p_ev_2d_h( 1 ) / p_ev_2d_h( 2 ) ) );

              if ( y < 0 || y >= height_ev || x < 0 || x >= width_ev )
                continue;

              if ( time_surface.image.at<uchar>( y, x ) >= 80 )
                {
                  double          x = p.x;
                  double          y = p.y;
                  double          z = p.z;
                  Eigen::Vector3d p_cam;
                  p_cam << x, y, z;

                  Eigen::Vector3d p_world = T_world_result.block<3, 3>( 0, 0 ) * p_cam + T_world_result.block<3, 1>( 0, 3 );
                  // pc_local_->push_back(pcl::PointXYZ(p_world(0), p_world(1), p_world(2)));
                  ref_frame.vPointXYZPtr_.push_back( new pcl::PointXYZ( p_world( 0 ), p_world( 1 ), p_world( 2 ) ) );
                  // pc_for_icp_cur_sd.push_back( p );
                }
            }

          if ( visualize )
            {

              sensor_msgs::PointCloud2::Ptr pc_to_publish( new sensor_msgs::PointCloud2 );
              pcl::toROSMsg( pc_ev, *pc_to_publish );
              pc_to_publish->header.frame_id = "map";
              pc_to_publish->header.stamp    = ros::Time::now();
              // publish pointcloud
              pub_semi_dense.publish( *pc_to_publish );
              pub_rgb.publish( queue_rgb[depth_count] );
              pub_depth.publish( queue_depth[depth_count] );
            }

          ROS_WARN_COND( ref_frame.vPointXYZPtr_.size() < 1000, "So few semi dense point cloud: %ld", ref_frame.vPointXYZPtr_.size() );

          if ( t.INIT == false )
            {
              /* init state */
              pc_for_icp_old.swap( queue_pc[depth_count] );
              // pc_for_icp_old.swap( pc_for_icp_cur);
              ref_frame.tr_.setIdentity();
              ref_frame.t_ = t.ts;
              cur_frame.tr_.setIdentity();
              cur_frame.t_      = t.ts;
              cur_frame.pTsObs_ = nullptr;
            }
        }

      if ( t.SD )
        {
          depth_count++; /* increate key frame count */
        }

      if ( verbose )
        ROS_INFO_STREAM( "[Trace] timeline state: <TS|SD|ED|ICP|INIT> "
                         << "|" << t.TS << "|" << t.SD << "|" << t.ED << "|" << t.ICP << "|" << t.INIT << "|" << std::fixed << std::setprecision( 6 ) << t.ts.toSec() );
    }
  if ( bSaveTrajectory )
    {
      saveTrajectory( resultPath + "result.txt" );
    }
}

void dataloading()
{
  ROS_INFO( "start dataloading..." );

  rosbag::Bag bag;

  bag.open( bag_path, rosbag::bagmode::Read );

  std::vector<std::string> topics{ event_topic, depth_topic, rgb_topic, gt_topic };

  rosbag::View view( bag, rosbag::TopicQuery( topics ) );

  int depth_downsample_count = 0;
  int rgb_downsample_count   = 0;
  int rgb_downsample_factor  = depth_downsample_factor;

  for ( rosbag::MessageInstance const m : rosbag::View( bag ) )
    {
      std::string topic = m.getTopic();

      if ( topic == event_topic )
        {
          EventArray::ConstPtr eap = m.instantiate<EventArray>();
          for ( Event e : eap->events )
            queue_ev.emplace_back( e );
        }
      else if ( topic == depth_topic )
        {
          if ( depth_downsample_count++ % depth_downsample_factor == 0 )
            {
              sensor_msgs::ImageConstPtr dep = m.instantiate<sensor_msgs::Image>();
              queue_depth.emplace_back( *dep );
            }
        }
      else if ( topic == rgb_topic )
        {
          if ( rgb_downsample_count++ % rgb_downsample_factor == 0 )
            {
              sensor_msgs::ImageConstPtr rgb = m.instantiate<sensor_msgs::Image>();
              queue_rgb.emplace_back( *rgb );
            }
        }
      else if ( topic == gt_topic )
        {
          geometry_msgs::PoseStamped::ConstPtr pose = m.instantiate<geometry_msgs::PoseStamped>();
          queue_gt.push_back( *pose );
        }
    }

  bag.close();

  std::sort( queue_ev.begin(), queue_ev.end(), []( const Event &a, const Event &b ) -> bool { return a.ts < b.ts; } );
  std::sort( queue_depth.begin(), queue_depth.end(), []( const sensor_msgs::Image &a, const sensor_msgs::Image &b ) -> bool { return a.header.stamp < b.header.stamp; } );
  std::sort( queue_rgb.begin(), queue_rgb.end(), []( const sensor_msgs::Image &a, const sensor_msgs::Image &b ) -> bool { return a.header.stamp < b.header.stamp; } );

  queue_depth.resize( std::min( queue_depth.size(), queue_rgb.size() ) );
  queue_rgb.resize( std::min( queue_depth.size(), queue_rgb.size() ) );

  if ( verbose )
    {
      std::cout << "[Bag Stat] N depth maps: " << queue_depth.size() << std::endl;
      std::cout << "[Bag Stat] N events: " << queue_ev.size() << std::endl;
      std::cout << "[Bag Stat] N rgb images: " << queue_rgb.size() << std::endl;
      std::cout << "[Bag Stat] All data is sorted. " << std::endl;
      std::cout << "[Bag Stat] Type of rgb image: " << queue_rgb[0].encoding << "\t[" << queue_rgb[0].height << "x" << queue_rgb[0].width << "]" << std::endl;
      std::cout << "[Bag Stat] Type of depth image: " << queue_depth[0].encoding << "\t[" << queue_depth[0].height << "x" << queue_depth[0].width << "]" << std::endl;
    }
}

/************ publish results *******************/
void publishPose( const ros::Time &t, Transformation &tr )
{
  geometry_msgs::PoseStampedPtr ps_ptr( new geometry_msgs::PoseStamped() );
  ps_ptr->header.stamp       = t;
  ps_ptr->header.frame_id    = "map";
  ps_ptr->pose.position.x    = tr.getPosition()( 0 );
  ps_ptr->pose.position.y    = tr.getPosition()( 1 );
  ps_ptr->pose.position.z    = tr.getPosition()( 2 );
  ps_ptr->pose.orientation.x = tr.getRotation().x();
  ps_ptr->pose.orientation.y = tr.getRotation().y();
  ps_ptr->pose.orientation.z = tr.getRotation().z();
  ps_ptr->pose.orientation.w = tr.getRotation().w();
  pub_pose.publish( ps_ptr );
}

void publishPath( const ros::Time &t, Transformation &tr )
{
  geometry_msgs::PoseStampedPtr ps_ptr( new geometry_msgs::PoseStamped() );
  ps_ptr->header.stamp       = t;
  ps_ptr->header.frame_id    = "map";
  ps_ptr->pose.position.x    = tr.getPosition().x();
  ps_ptr->pose.position.y    = tr.getPosition().y();
  ps_ptr->pose.position.z    = tr.getPosition().z();
  ps_ptr->pose.orientation.x = tr.getRotation().x();
  ps_ptr->pose.orientation.y = tr.getRotation().y();
  ps_ptr->pose.orientation.z = tr.getRotation().z();
  ps_ptr->pose.orientation.w = tr.getRotation().w();

  path.header.stamp    = t;
  path.header.frame_id = "map";
  path.poses.push_back( *ps_ptr );
  pub_path.publish( path );
}

void saveTrajectory( const std::string &resultDir )
{
  LOG( INFO ) << "Saving trajectory to " << resultDir << " ......";

  std::ofstream f;
  f.open( resultDir.c_str(), std::ofstream::out );
  if ( !f.is_open() )
    {
      LOG( INFO ) << "File at " << resultDir << " is not opened, save trajectory failed.";
      exit( -1 );
    }
  f << std::fixed;

  std::list<Eigen::Matrix<double, 4, 4>, Eigen::aligned_allocator<Eigen::Matrix<double, 4, 4>>>::iterator result_it_begin = lPose.begin();
  std::list<Eigen::Matrix<double, 4, 4>, Eigen::aligned_allocator<Eigen::Matrix<double, 4, 4>>>::iterator result_it_end   = lPose.end();
  std::list<std::string>::iterator                                                                        ts_it_begin     = lTimestamp.begin();

  for ( ; result_it_begin != result_it_end; result_it_begin++, ts_it_begin++ )
    {
      Eigen::Matrix3d Rwc_result;
      Eigen::Vector3d twc_result;
      Rwc_result = ( *result_it_begin ).block<3, 3>( 0, 0 );
      twc_result = ( *result_it_begin ).block<3, 1>( 0, 3 );
      Eigen::Quaterniond q( Rwc_result );
      f << *ts_it_begin << " " << std::setprecision( 9 ) << twc_result.transpose() << " " << q.x() << " " << q.y() << " " << q.z() << " " << q.w() << std::endl;
    }
  f.close();
  LOG( INFO ) << "saving trajectory to " << resultDir << ". Done !";

  f.open( resultPath + "gt.txt", std::ofstream::out );

  if ( queue_gt.size() != 0 )
    {
      Eigen::Quaterniond quat( queue_gt[0].pose.orientation.w, queue_gt[0].pose.orientation.x, queue_gt[0].pose.orientation.y, queue_gt[0].pose.orientation.z );
      Eigen::Vector3d    t( queue_gt[0].pose.position.x, queue_gt[0].pose.position.y, queue_gt[0].pose.position.z );
      quat.normalize();
      Transformation T_init( t, quat );
      gt_path.header.frame_id = "map";
      for ( int i = 0; i < queue_gt.size(); i++ )
        {
          Eigen::Quaterniond quat( queue_gt[i].pose.orientation.w, queue_gt[i].pose.orientation.x, queue_gt[i].pose.orientation.y, queue_gt[i].pose.orientation.z );
          Eigen::Vector3d    t( queue_gt[i].pose.position.x, queue_gt[i].pose.position.y, queue_gt[i].pose.position.z );

          quat.normalize();

          Transformation T( t, quat );
          Transformation T_rel = T_init.inverse() * T;

          geometry_msgs::PoseStamped pose;

          pose.pose.orientation.w = T_rel.getRotation().w();
          pose.pose.orientation.x = T_rel.getRotation().x();
          pose.pose.orientation.y = T_rel.getRotation().y();
          pose.pose.orientation.z = T_rel.getRotation().z();
          pose.pose.position.x    = T_rel.getPosition().x();
          pose.pose.position.y    = T_rel.getPosition().y();
          pose.pose.position.z    = T_rel.getPosition().z();
          pose.header.stamp       = ros::Time::now();
          pose.header.frame_id    = "map";

          gt_path.poses.push_back( pose );
          gt_path.header.stamp = pose.header.stamp;

          pub_gt.publish( gt_path );

          ros::Duration().fromSec( 0.01 ).sleep();

          f << queue_gt[i].header.stamp.toSec() << " " << std::setprecision( 9 ) << T_rel.getPosition().transpose() << " " << T_rel.getRotation().x() << " " << T_rel.getRotation().y() << " "
            << T_rel.getRotation().z() << " " << T_rel.getRotation().w() << std::endl;
        }
    }
  f.close();
  LOG( INFO ) << "saving trajectory to " << resultPath + "gt.txt"
              << ". Done !";
}

bool getVerbose() { return verbose; }

bool getVisualize() { return visualize; }

void setVerbose() { verbose = true; }

void unsetVerbose() { verbose = false; }

void setVisualize() { visualize = true; }

void unsetVisualize() { visualize = false; }

Eigen::Matrix<double, 3, 4> getP_ev() { return P_ev; }

int getHeight_ev() { return height_ev; }

int getWidth_ev() { return width_ev; }
} // namespace offline
} // namespace esvo_plus
