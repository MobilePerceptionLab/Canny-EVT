#include <esvo_plus/esvo_plus_optimization.h>

namespace esvo_plus
{
namespace optimization
{
using namespace types;

RegProblem::RegProblem()
{
  //std::cout << "[Trace] to be implemented" << std::endl;
  optimization::OptimizationFunctor<double>( 6, 0 );
  computeJ_G( Eigen::Matrix<double, 6, 1>::Zero(), J_G_0_ );
}

void RegProblem::setProblem( RefFrame *ref, CurFrame *cur )
{
  ref_                        = ref;
  cur_                        = cur;
  T_world_ref_                = ref_->tr_.getTransformationMatrix();
  T_world_ev_                 = cur_->tr_.getTransformationMatrix();
  Eigen::Matrix4d T_ref_ev    = T_world_ref_.inverse() * T_world_ev_;
  R_                          = T_ref_ev.block<3, 3>( 0, 0 );
  t_                          = T_ref_ev.block<3, 1>( 0, 3 );
  Eigen::Matrix3d R_world_ref = T_world_ref_.block<3, 3>( 0, 0 );
  Eigen::Vector3d t_world_ref = T_world_ref_.block<3, 1>( 0, 3 );

  // load ref's pointcloud tp vResItem
  ResItems_.clear();
  numPoints_ = ref_->pc_.size();
  if ( numPoints_ > MAX_REGISTRATION_POINTS_ )
    numPoints_ = MAX_REGISTRATION_POINTS_;
  ResItems_.resize( numPoints_ );

  for ( size_t i = 0; i < numPoints_; i++ )
    {
      bool bStochasticSampling = true;
      if ( bStochasticSampling )
        std::swap( ref->pc_[i], ref->pc_[i + rand() % ( ref->pc_.size() - i )] );
      Eigen::Vector3d p_tmp( (double)ref->pc_[i].x, (double)ref->pc_[i].y, (double)ref->pc_[i].z );
      Eigen::Vector3d p_cam = R_world_ref.transpose() * ( p_tmp - t_world_ref );
      ResItems_[i].initialize( p_cam( 0 ), p_cam( 1 ), p_cam( 2 ) ); //, var);
    }
  // for stochastic sampling
  numBatches_ = std::max( ResItems_.size() / BATCH_SIZE_, (size_t)1 );

  // load cur's info
  TS_ = cur->ts_;
  cv::cv2eigen( TS_, TS_eigen_ );
  // set fval dimension
  resetNumberValues( numPoints_ * patchSize_ );
}

void RegProblem::setStochasticSampling( size_t offset, size_t N )
{
  ResItemsStochSampled_.clear();
  ResItemsStochSampled_.reserve( N );
  for ( size_t i = 0; i < N; i++ )
    {
      if ( offset + i >= ResItems_.size() )
        break;
      ResItemsStochSampled_.push_back( ResItems_[offset + i] );
    }
  numPoints_ = ResItemsStochSampled_.size();
  resetNumberValues( numPoints_ * patchSize_ );
}

void RegProblem::getWarpingTransformation( Eigen::Matrix4d &warpingTransf, const Eigen::Matrix<double, 6, 1> &x ) const
{
  // To calcuate R_cur_ref, t_cur_ref
  Eigen::Matrix3d R_cur_ref;
  Eigen::Vector3d t_cur_ref;
  // get delta cayley paramters (this corresponds to the delta motion of the ref frame)
  Eigen::Vector3d dc = x.block<3, 1>( 0, 0 );
  Eigen::Vector3d dt = x.block<3, 1>( 3, 0 );
  // add rotation
  Eigen::Matrix3d dR   = cayley2rot( dc );
  Eigen::Matrix3d newR = R_.transpose() * dR.transpose();

  Eigen::JacobiSVD<Eigen::Matrix3d> svd( newR, Eigen::ComputeFullU | Eigen::ComputeFullV );
  R_cur_ref = svd.matrixU() * svd.matrixV().transpose();
  if ( R_cur_ref.determinant() < 0.0 )
    {
      LOG( INFO ) << "oops the matrix is left-handed\n";
      exit( -1 );
    }
  t_cur_ref = -R_cur_ref * ( dt + dR * t_ );

  warpingTransf.block<3, 3>( 0, 0 ) = R_cur_ref;
  warpingTransf.block<3, 1>( 0, 3 ) = t_cur_ref;
}

Eigen::Matrix3d RegProblem::cayley2rot( const Eigen::Vector3d &cayley ) const
{
  Eigen::Matrix3d R;
  double          scale = 1 + pow( cayley[0], 2 ) + pow( cayley[1], 2 ) + pow( cayley[2], 2 );

  R( 0, 0 ) = 1 + pow( cayley[0], 2 ) - pow( cayley[1], 2 ) - pow( cayley[2], 2 );
  R( 0, 1 ) = 2 * ( cayley[0] * cayley[1] - cayley[2] );
  R( 0, 2 ) = 2 * ( cayley[0] * cayley[2] + cayley[1] );
  R( 1, 0 ) = 2 * ( cayley[0] * cayley[1] + cayley[2] );
  R( 1, 1 ) = 1 - pow( cayley[0], 2 ) + pow( cayley[1], 2 ) - pow( cayley[2], 2 );
  R( 1, 2 ) = 2 * ( cayley[1] * cayley[2] - cayley[0] );
  R( 2, 0 ) = 2 * ( cayley[0] * cayley[2] - cayley[1] );
  R( 2, 1 ) = 2 * ( cayley[1] * cayley[2] + cayley[0] );
  R( 2, 2 ) = 1 - pow( cayley[0], 2 ) - pow( cayley[1], 2 ) + pow( cayley[2], 2 );

  R = ( 1 / scale ) * R;
  return R;
}

void RegProblem::addMotionUpdate( const Eigen::Matrix<double, 6, 1> &dx )
{
  // To update R_, t_
  Eigen::Vector3d dc = dx.block<3, 1>( 0, 0 );
  Eigen::Vector3d dt = dx.block<3, 1>( 3, 0 );
  // add rotation
  Eigen::Matrix3d dR   = cayley2rot( dc );
  Eigen::Matrix3d newR = dR * R_;
  // ROS_INFO_STREAM("newR"<<newR);
  Eigen::JacobiSVD<Eigen::Matrix3d> svd( newR, Eigen::ComputeFullU | Eigen::ComputeFullV );
  R_ = svd.matrixU() * svd.matrixV().transpose();
  // ROS_INFO_STREAM("R_"<<R_);
  t_ = dt + dR * t_;
}

void RegProblem::setPose()
{
  T_world_ev_.block<3, 3>( 0, 0 ) = T_world_ref_.block<3, 3>( 0, 0 ) * R_;
  T_world_ev_.block<3, 1>( 0, 3 ) = T_world_ref_.block<3, 3>( 0, 0 ) * t_ + T_world_ref_.block<3, 1>( 0, 3 );
  cur_->tr_                       = Transformation( T_world_ev_ );
}

int RegProblem::operator()( const Eigen::Matrix<double, 6, 1> &x, Eigen::VectorXd &fvec ) const
{
  std::cout << "[Trace] to be implemented" << std::endl;
  // size of patch
  size_t wx = 1;
  size_t wy = 1;

  size_t numPoint    = ResItems_.size();
  size_t residualDim = wx * wy;

  // ri.residual_ = Eigen::VectorXd(residualDim);
  // Eigen::Vector2d x1_s;

  for ( size_t i = 0; i < numPoint; i++ )
    {
      ResidualItem ri = const_cast<ResidualItem &>( ResItems_[i] );
      ri.residual_    = Eigen::VectorXd( residualDim );
      Eigen::Vector2d x1_s;
      if ( !reprojection( ri.p_, T_ev_ref_, x1_s ) )
        ri.residual_.setConstant( 255.0 );
      else
        {
          Eigen::MatrixXd tau1;
          if ( patchInterpolation( TS_eigen_, x1_s, tau1 ) )
            {
              for ( size_t y = 0; y < wy; y++ )
                for ( size_t x = 0; x < wx; x++ )
                  {
                    size_t index        = y * wx + x;
                    ri.residual_[index] = tau1( y, x );
                  }
            }
          else
            ri.residual_.setConstant( 255.0 );
        }
    }

  // assign the reweighted residual to fveclef
  if ( L2 )
    {
      for ( size_t i = 0; i < ResItemsStochSampled_.size(); i++ )
        {
          ResidualItem &ri                                             = const_cast<ResidualItem &>( ResItemsStochSampled_[i] );
          fvec.segment( i * ri.residual_.size(), ri.residual_.size() ) = ri.residual_; // / sqrt(var);
        }
    }
  if ( Huber )
    {
      for ( size_t i = 0; i < ResItemsStochSampled_.size(); i++ )
        {
          ResidualItem &ri          = const_cast<ResidualItem &>( ResItemsStochSampled_[i] );
          double        irls_weight = 1.0;
          if ( ri.residual_( 0 ) > 50 )
            irls_weight = 50 / ri.residual_( 0 );
          fvec[i] = sqrt( irls_weight ) * ri.residual_( 0 );
        }
    }
  return 0;
}

bool RegProblem::patchInterpolation( const Eigen::MatrixXd &img, const Eigen::Vector2d &location, Eigen::MatrixXd &patch ) const
{
  int wx = 1;
  int wy = 1;
  // compute SrcPatch_UpLeft coordinate and SrcPatch_DownRight coordinate
  // check patch bourndary is inside img boundary
  Eigen::Vector2i SrcPatch_UpLeft, SrcPatch_DownRight;
  SrcPatch_UpLeft << floor( location[0] ) - ( wx - 1 ) / 2, floor( location[1] ) - ( wy - 1 ) / 2;
  SrcPatch_DownRight << floor( location[0] ) + ( wx - 1 ) / 2, floor( location[1] ) + ( wy - 1 ) / 2;

  if ( SrcPatch_UpLeft[0] < 0 || SrcPatch_UpLeft[1] < 0 )
    {
      return false;
    }
  if ( SrcPatch_DownRight[0] >= img.cols() || SrcPatch_DownRight[1] >= img.rows() )
    {
      return false;
    }

  // compute q1 q2 q3 q4
  Eigen::Vector2d double_indices;
  double_indices << location[1], location[0];

  std::pair<int, int> lower_indices( floor( double_indices[0] ), floor( double_indices[1] ) );
  std::pair<int, int> upper_indices( lower_indices.first + 1, lower_indices.second + 1 );

  double q1 = upper_indices.second - double_indices[1];
  double q2 = double_indices[1] - lower_indices.second;
  double q3 = upper_indices.first - double_indices[0];
  double q4 = double_indices[0] - lower_indices.first;

  // extract Src patch, size (wy+1) * (wx+1)
  int wx2 = wx + 1;
  int wy2 = wy + 1;
  if ( SrcPatch_UpLeft[1] + wy >= img.rows() || SrcPatch_UpLeft[0] + wx >= img.cols() )
    {
      return false;
    }
  Eigen::MatrixXd SrcPatch = img.block( SrcPatch_UpLeft[1], SrcPatch_UpLeft[0], wy2, wx2 );

  // Compute R, size (wy+1) * wx.
  Eigen::MatrixXd R;
  R = q1 * SrcPatch.block( 0, 0, wy2, wx ) + q2 * SrcPatch.block( 0, 1, wy2, wx );

  // Compute F, size wy * wx.
  patch = q3 * R.block( 0, 0, wy, wx ) + q4 * R.block( 1, 0, wy, wx );
  return true;
}

bool RegProblem::reprojection( const Eigen::Vector3d &p, const Eigen::Matrix4d &warpingTransf, Eigen::Vector2d &x1_s ) const
{
  // transfer to left DVS coordinate
  // Eigen::Vector2d        x1_s;
  const Eigen::Vector3d &p_ev = warpingTransf.block<3, 3>( 0, 0 ) * p + warpingTransf.block<3, 1>( 0, 3 );
  world2Cam( p_ev, x1_s );

  // if ( !isValidPatch( x1_s, camSysPtr_->cam_left_ptr_->UndistortRectify_mask_, 1, 1 ) )
  //   return false;
  return true;
}

void RegProblem::world2Cam( const Eigen::Vector3d &p, Eigen::Vector2d &x ) const
{
  Eigen::Vector3d x_hom = offline::getP_ev().block<3, 3>( 0, 0 ) * p + offline::getP_ev().block<3, 1>( 0, 3 );
  x                     = x_hom.head( 2 ) / x_hom( 2 );
}

bool RegProblem::isValidPatch( Eigen::Vector2d &patchCentreCoord, Eigen::MatrixXi &mask, size_t wx, size_t wy ) const
{
  if ( patchCentreCoord( 0 ) < ( wx - 1 ) / 2 || patchCentreCoord( 0 ) > offline::getWidth_ev() - ( wx - 1 ) / 2 - 1 || patchCentreCoord( 1 ) < ( wy - 1 ) / 2 ||
       patchCentreCoord( 1 ) > offline::getHeight_ev() - ( wy - 1 ) / 2 - 1 )
    return false;
  if ( mask( patchCentreCoord( 1 ) - ( wy - 1 ) / 2, patchCentreCoord( 0 ) - ( wx - 1 ) / 2 ) < 125 )
    return false;
  if ( mask( patchCentreCoord( 1 ) - ( wy - 1 ) / 2, patchCentreCoord( 0 ) + ( wx - 1 ) / 2 ) < 125 )
    return false;
  if ( mask( patchCentreCoord( 1 ) + ( wy - 1 ) / 2, patchCentreCoord( 0 ) - ( wx - 1 ) / 2 ) < 125 )
    return false;
  if ( mask( patchCentreCoord( 1 ) + ( wy - 1 ) / 2, patchCentreCoord( 0 ) + ( wx - 1 ) / 2 ) < 125 )
    return false;
  return true;
}

int RegProblem::df( const Eigen::Matrix<double, 6, 1> &x, Eigen::MatrixXd &fjac ) const
{
  const Eigen::Matrix<double, 3, 4> &P_ev = offline::getP_ev();
  std::cout << "[Trace] to be implemented" << std::endl;
  if ( x != Eigen::Matrix<double, 6, 1>::Zero() )
    {
      LOG( INFO ) << "The Jacobian is not evaluated at Zero !!!!!!!!!!!!!";
      exit( -1 );
    }
  fjac.resize( m_values, 6 );
  // J_x = dPi_dT * dT_dInvPi * dInvPi_dx
  Eigen::Matrix3d             dT_dInvPi = R_.transpose(); // Explaination for the transpose() can be found below.
  Eigen::Matrix<double, 3, 2> dInvPi_dx_constPart;
  dInvPi_dx_constPart.setZero();
  dInvPi_dx_constPart( 0, 0 )             = 1.0 / P_ev( 0, 0 );
  dInvPi_dx_constPart( 1, 1 )             = 1.0 / P_ev( 1, 1 );
  Eigen::Matrix<double, 3, 2> J_constPart = dT_dInvPi * dInvPi_dx_constPart;

  // J_theta = dPi_dT * dT_dG * dG_dtheta
  // Assemble the Jacobian without dG_dtheta.
  Eigen::MatrixXd fjacBlock;
  fjacBlock.resize( numPoints_, 12 );
  Eigen::MatrixXd fjacTMP( 3, 6 ); // FOR Test
  Eigen::Matrix4d T_ev_ref     = Eigen::Matrix4d::Identity();
  T_ev_ref.block<3, 3>( 0, 0 ) = R_.transpose();
  T_ev_ref.block<3, 1>( 0, 3 ) = -R_.transpose() * t_;

  const double P11 = P_ev( 0, 0 );
  const double P12 = P_ev( 0, 1 );
  const double P14 = P_ev( 0, 3 );
  const double P21 = P_ev( 1, 0 );
  const double P22 = P_ev( 1, 1 );
  const double P24 = P_ev( 1, 3 );

  for ( size_t i = 0; i < numPoints_; i++ )
    {
      Eigen::Vector2d     x1_s;
      const ResidualItem &ri = ResItemsStochSampled_[i];
      if ( !reprojection( ri.p_, T_ev_ref, x1_s ) )
        fjacBlock.row( i ) = Eigen::Matrix<double, 1, 12>::Zero();
      else
        {
          // obtain the exact gradient by bilinear interpolation.
          Eigen::MatrixXd gx, gy;

          patchInterpolation( TS_eigen_, x1_s, gx );
          patchInterpolation( TS_eigen_, x1_s, gy );
          Eigen::Vector2d grad = Eigen::Vector2d( gx( 0, 0 ) / 8, gy( 0, 0 ) / 8 ); // 8 is the normalization factor for 3x3 sobel filter.

          Eigen::Matrix<double, 2, 3> dPi_dT;
          dPi_dT.setZero();
          dPi_dT.block<2, 2>( 0, 0 ) = P_ev.block<2, 2>( 0, 0 ) / ri.p_( 2 );
          const double z2            = pow( ri.p_( 2 ), 2 );
          dPi_dT( 0, 2 )             = -( P11 * ri.p_( 0 ) + P12 * ri.p_( 1 ) + P14 ) / z2;
          dPi_dT( 1, 2 )             = -( P21 * ri.p_( 0 ) + P22 * ri.p_( 1 ) + P24 ) / z2;

          // assemble dT_dG
          Eigen::Matrix<double, 3, 12> dT_dG;
          dT_dG.setZero();
          dT_dG.block<3, 3>( 0, 0 ) = ri.p_( 0 ) * Eigen::Matrix3d::Identity();
          dT_dG.block<3, 3>( 0, 3 ) = ri.p_( 1 ) * Eigen::Matrix3d::Identity();
          dT_dG.block<3, 3>( 0, 6 ) = ri.p_( 2 ) * Eigen::Matrix3d::Identity();
          dT_dG.block<3, 3>( 0, 9 ) = Eigen::Matrix3d::Identity();
          //      LOG(INFO) << "dT_dG:\n" << dT_dG;
          fjacBlock.row( i ) = grad.transpose() * dPi_dT * J_constPart * dPi_dT * dT_dG * ri.p_( 2 ); // ri.p_(2) refers to 1/rho_i which is actually coming with dInvPi_dx.
        }
    }
  // assemble with dG_dtheta
  fjac = -fjacBlock * J_G_0_;
  return 0;
}

void RegProblem::computeJ_G( const Eigen::Matrix<double, 6, 1> &x, Eigen::Matrix<double, 12, 6> &J_G )
{
  assert( x.size() == 6 );
  assert( J_G.rows() == 12 && J_G.cols() == 6 );
  double c1, c2, c3, k;
  double c1_sq, c2_sq, c3_sq, k_sq;
  c1    = x( 0 );
  c2    = x( 1 );
  c3    = x( 2 );
  c1_sq = pow( c1, 2 );
  c2_sq = pow( c2, 2 );
  c3_sq = pow( c3, 2 );
  k     = 1 + pow( c1, 2 ) + pow( c2, 2 ) + pow( c3, 2 );
  k_sq  = pow( k, 2 );
  Eigen::Matrix3d A1, A2, A3;
  // A1
  A1( 0, 0 ) = 2 * c1 / k - 2 * c1 * ( 1 + c1_sq - c2_sq - c3_sq ) / k_sq;
  A1( 0, 1 ) = -2 * c2 / k - 2 * c2 * ( 1 + c1_sq - c2_sq - c3_sq ) / k_sq;
  A1( 0, 2 ) = -2 * c3 / k - 2 * c3 * ( 1 + c1_sq - c2_sq - c3_sq ) / k_sq;
  A1( 1, 0 ) = 2 * c2 / k - 4 * c1 * ( c1 * c2 + c3 ) / k_sq;
  A1( 1, 1 ) = 2 * c1 / k - 4 * c2 * ( c1 * c2 + c3 ) / k_sq;
  A1( 1, 2 ) = 2 / k - 4 * c3 * ( c1 * c2 + c3 ) / k_sq;
  A1( 2, 0 ) = 2 * c3 / k - 4 * c1 * ( c1 * c3 - c2 ) / k_sq;
  A1( 2, 1 ) = -2 / k + 4 * c2 * ( c1 * c3 - c2 ) / k_sq;
  A1( 2, 2 ) = 2 * c1 / k - 4 * c3 * ( c1 * c3 - c2 ) / k_sq;
  // A2
  A2( 0, 0 ) = 2 * c2 / k - 4 * c1 * ( c1 * c2 - c3 ) / k_sq;
  A2( 0, 1 ) = 2 * c1 / k - 4 * c2 * ( c1 * c2 - c3 ) / k_sq;
  A2( 0, 2 ) = -2 / k - 4 * c3 * ( c1 * c2 - c3 ) / k_sq;
  A2( 1, 0 ) = -2 * c1 / k - 2 * c1 * ( 1 - c1_sq + c2_sq - c3_sq ) / k_sq;
  A2( 1, 1 ) = 2 * c2 / k - 2 * c2 * ( 1 - c1_sq + c2_sq - c3_sq ) / k_sq;
  A2( 1, 2 ) = -2 * c3 / k - 2 * c3 * ( 1 - c1_sq + c2_sq - c3_sq ) / k_sq;
  A2( 2, 0 ) = 2 / k - 4 * c1 * ( c1 + c2 * c3 ) / k_sq;
  A2( 2, 1 ) = 2 * c3 / k - 4 * c2 * ( c1 + c2 * c3 ) / k_sq;
  A2( 2, 2 ) = 2 * c2 / k - 4 * c3 * ( c1 + c2 * c3 ) / k_sq;
  // A3
  A3( 0, 0 ) = 2 * c3 / k - 4 * c1 * ( c2 + c1 * c3 ) / k_sq;
  A3( 0, 1 ) = 2 / k - 4 * c2 * ( c2 + c1 * c3 ) / k_sq;
  A3( 0, 2 ) = 2 * c1 / k - 4 * c3 * ( c2 + c1 * c3 ) / k_sq;
  A3( 1, 0 ) = -2 / k - 4 * c1 * ( c2 * c3 - c1 ) / k_sq;
  A3( 1, 1 ) = 2 * c3 / k - 4 * c2 * ( c2 * c3 - c1 ) / k_sq;
  A3( 1, 2 ) = 2 * c2 / k - 4 * c3 * ( c2 * c3 - c1 ) / k_sq;
  A3( 2, 0 ) = -2 * c1 / k - 2 * c1 * ( 1 - c1_sq - c2_sq + c3_sq ) / k_sq;
  A3( 2, 1 ) = -2 * c2 / k - 2 * c2 * ( 1 - c1_sq - c2_sq + c3_sq ) / k_sq;
  A3( 2, 2 ) = 2 * c3 / k - 2 * c3 * ( 1 - c1_sq - c2_sq + c3_sq ) / k_sq;

  Eigen::Matrix3d O33     = Eigen::MatrixXd::Zero( 3, 3 );
  Eigen::Matrix3d I33     = Eigen::MatrixXd::Identity( 3, 3 );
  J_G.block<3, 3>( 0, 0 ) = A1;
  J_G.block<3, 3>( 0, 3 ) = O33;
  J_G.block<3, 3>( 3, 0 ) = A2;
  J_G.block<3, 3>( 3, 3 ) = O33;
  J_G.block<3, 3>( 6, 0 ) = A3;
  J_G.block<3, 3>( 6, 3 ) = O33;
  J_G.block<3, 3>( 9, 0 ) = O33;
  J_G.block<3, 3>( 9, 3 ) = I33;
}

ResidualItem::ResidualItem() = default;

ResidualItem::ResidualItem( const double x, const double y, const double z ) { initialize( x, y, z ); }

void ResidualItem::initialize( const double x, const double y, const double z ) { p_ = Eigen::Vector3d( x, y, z ); }

RegProblemSolver::RegProblemSolver()
{
  regProblemPtr_ = std::make_shared<RegProblem>();

  lmStatics_.nPoints_ = 0;
  lmStatics_.nfev_    = 0;
  lmStatics_.nIter_   = 0;
}

RegProblemSolver::~RegProblemSolver() {}

bool RegProblemSolver::resetRegProblem( RefFrame *ref, CurFrame *cur )
{

  if ( ref->pc_.size() < 300 )
    {
      // ROS_INFO("00000");
      LOG( INFO ) << "resetRegProblem RESET fails for no enough point cloud in the local map.";
      LOG( INFO ) << "The system will be re-initialized";
      return false;
    }

  regProblemPtr_->setProblem( ref, cur );

  lmStatics_.nPoints_ = 0;
  lmStatics_.nfev_    = 0;
  lmStatics_.nIter_   = 0;
  return true;
}

bool RegProblemSolver::solve_analytical()
{
  Eigen::LevenbergMarquardt<RegProblem, double> lm( *regProblemPtr_ );

  lm.resetParameters();
  lm.parameters.ftol   = 1e-3;
  lm.parameters.xtol   = 1e-3;
  lm.parameters.maxfev = 100;

  size_t iteration = 0;
  size_t nfev      = 0;
  constexpr size_t max_iterations = 100;
  constexpr size_t batch_size     = 300;
  while ( true )
    {
      if ( iteration > max_iterations )
        break;

      /** TODO: implement stochastic sampling */
      regProblemPtr_->setStochasticSampling( ( iteration % regProblemPtr_->numBatches_ ) * batch_size, batch_size );
      Eigen::VectorXd x( 6 );
      x.fill( 0.0 );

      if ( lm.minimizeInit( x ) == Eigen::LevenbergMarquardtSpace::ImproperInputParameters )
        {

          LOG( ERROR ) << "ImproperInputParameters for LM (Tracking)." << std::endl;

          return false;
        }
      ROS_INFO_STREAM(x);
      Eigen::LevenbergMarquardtSpace::Status status = lm.minimizeOneStep( x );
      /** TODO: implement motion update here */
      regProblemPtr_->addMotionUpdate( x );
      iteration++;

      nfev += lm.nfev;

      if ( status == 2 || status == 3 )
        break;

      return 0;
    }

  /**
   * TODO: update pose here
   */

  regProblemPtr_->setPose();
  lmStatics_.nPoints_ = regProblemPtr_->numPoints_;
  lmStatics_.nfev_    = nfev;
  lmStatics_.nIter_   = iteration;

  if ( offline::getVerbose() )
    {
      std::cout << "[Optimization]" << nfev << std::endl;
      std::cout << "[Optimization]" << iteration << std::endl;
    }

  return true;
}

} // namespace optimization
} // namespace esvo_plus