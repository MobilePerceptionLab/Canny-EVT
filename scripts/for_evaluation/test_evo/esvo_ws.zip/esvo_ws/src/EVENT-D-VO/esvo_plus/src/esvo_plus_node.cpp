#include <esvo_plus/esvo_plus_offline.h>
#include <image_transport/image_transport.h>
#include <iostream>
#include <ros/ros.h>
#include <string>

int main( int argc, char **argv )
{
  ros::init( argc, argv, "esvo_plus_node" );

  ros::NodeHandle nh;

  image_transport::ImageTransport it( nh );

  std::string config_path( argv[1] );

  esvo_plus::offline::setVerbose();

  esvo_plus::offline::setVisualize();

  esvo_plus::offline::prelude( config_path );

  esvo_plus::offline::init( &nh, &it );

  esvo_plus::offline::dataloading();

  esvo_plus::offline::main();

  ROS_INFO( "finished..." );

  ros::shutdown();

  return 0;
}