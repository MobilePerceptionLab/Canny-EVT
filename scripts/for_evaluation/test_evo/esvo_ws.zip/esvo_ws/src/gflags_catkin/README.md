gflags_catkin
=============

A catkin wrapper for Google gflags
